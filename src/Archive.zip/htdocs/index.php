<?php
// Copyright 1999-2017. Parallels IP Holdings GmbH.

$application = new pm_Application();
$application->run();
