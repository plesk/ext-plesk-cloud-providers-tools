<?php
// Copyright 1999-2017. Parallels IP Holdings GmbH.

namespace Modules_PleskCloudProviders_Provider;

class Dump
{
    /**
     * @var array
     */
    public $ipv4 = [];
    /**
     * @var array
     */
    public $ipv6 = [];
    /**
     * @var string
     */
    public $password;
}
