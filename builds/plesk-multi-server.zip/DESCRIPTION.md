Plesk Multi Server extension allows managing multiple Plesk servers from a single place, as one would manage just the one Plesk server. All the customer accounts and subscriptions on all connected servers are created and managed in one centralized user interface. 

### Features 

- Centralized customer account management 
- Centralized subscription management 
- Subscription load balancing 
- Global server settings 
- Out of the box integration with WHMCS (https://marketplace.whmcs.com/product/2606) 
- Automation by means of XML API or CLI 

### Licensing 
Plesk Multi Server is a paid extension, each node requires two licenses be installed. It requires one **Plesk Product License Key** ("Web Pro" or "Web Host") and one **Plesk Multi Server Extension License Key** ($10 or €9 per month) be purchased and installed per node.

### More Information 
For more details on Plesk Multi Server, see the following [Plesk Multi Server Guide](https://docs.plesk.com/en-US/17.0/multi-server-guide/about-plesk-multi-server.77093/) 
