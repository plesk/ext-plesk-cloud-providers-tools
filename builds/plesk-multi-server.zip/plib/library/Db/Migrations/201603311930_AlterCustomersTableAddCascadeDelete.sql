PRAGMA foreign_keys = OFF;

CREATE TABLE IF NOT EXISTS `customers_new` (
  `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
  `slaveNodeId` INTEGER REFERENCES nodes(id) ON DELETE CASCADE,
  `masterId` INTEGER NOT NULL,
  `masterGuid` TEXT NOT NULL,
  `slaveId` INTEGER NOT NULL,
  `slaveGuid` TEXT NOT NULL,
  `login` TEXT
);

INSERT INTO customers_new(`id`, `slaveNodeId`, `masterId`, `masterGuid`, `slaveId`, `slaveGuid`, `login`)
  SELECT `id`, `slaveNodeId`, `masterId`, `masterGuid`, `slaveId`, `slaveGuid`, `login`
  FROM customers;

DROP TABLE customers;

ALTER TABLE customers_new RENAME TO customers;

PRAGMA foreign_keys = ON;
