CREATE TABLE IF NOT EXISTS `subscriptionIpAddresses` (
  `subscriptionId` INTEGER REFERENCES subscriptions(id) ON DELETE CASCADE,
  `ipAddress` TEXT NOT NULL REFERENCES ipAddresses(ipAddress) ON DELETE CASCADE,
   PRIMARY KEY (`subscriptionId`, `ipAddress`)
);
