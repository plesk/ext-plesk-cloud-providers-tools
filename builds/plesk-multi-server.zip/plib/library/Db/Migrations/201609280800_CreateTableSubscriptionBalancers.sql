CREATE TABLE IF NOT EXISTS balancerParameters (
  `subscriptionMasterId` INTEGER NOT NULL PRIMARY KEY,
  `taskId` INTEGER REFERENCES tasks(id) ON DELETE CASCADE,
  `ipv4Type` TEXT CHECK(`ipv4Type` IN ('none','exclusive','shared')) NOT NULL DEFAULT 'none',
  `ipv6Type` TEXT CHECK(`ipv6Type` IN ('none','exclusive','shared')) NOT NULL DEFAULT 'none'
);
