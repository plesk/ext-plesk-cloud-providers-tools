ALTER TABLE `subscriptions` ADD COLUMN `status` TEXT CHECK(`status` IN ('SYNC','DONE','ERR')) NOT NULL DEFAULT 'SYNC';
