CREATE TABLE IF NOT EXISTS `tasks` (
  `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
  `createDate` TEXT NOT NULL DEFAULT (strftime('%s','now')),
  `parentId` INTEGER REFERENCES tasks(id) ON DELETE SET NULL,
  `objectType` TEXT NOT NULL,
  `action` TEXT NOT NULL,
  `masterCustomerId` INTEGER,
  `masterSubscriptionId` INTEGER,
  `masterServicePlanId` INTEGER,
  `oldValues` TEXT,
  `newValues` TEXT,
  `nodeId` INTEGER REFERENCES nodes(id),
  `status` INTEGER DEFAULT 0 NOT NULL,
  `statusMessage` TEXT
);
