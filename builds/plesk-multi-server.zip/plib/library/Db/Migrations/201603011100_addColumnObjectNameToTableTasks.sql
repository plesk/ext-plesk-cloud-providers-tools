ALTER TABLE `tasks` ADD COLUMN `objectName` TEXT;
