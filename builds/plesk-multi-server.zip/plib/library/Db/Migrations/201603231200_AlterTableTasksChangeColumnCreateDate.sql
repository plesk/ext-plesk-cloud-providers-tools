PRAGMA foreign_keys = OFF;

CREATE TABLE IF NOT EXISTS `tasks_new` (
  `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
  `createdAt` DATETIME NOT NULL DEFAULT (strftime('%s','now')),
  `updatedAt` DATETIME NOT NULL DEFAULT (strftime('%s','now')),
  `parentId` INTEGER REFERENCES tasks_new(id) ON DELETE SET NULL,
  `objectType` TEXT NOT NULL,
  `action` TEXT NOT NULL,
  `masterCustomerId` INTEGER,
  `masterSubscriptionId` INTEGER,
  `masterServicePlanId` INTEGER,
  `oldValues` TEXT,
  `newValues` TEXT,
  `nodeId` INTEGER REFERENCES nodes(id) ON DELETE CASCADE,
  `status` INTEGER DEFAULT 0 NOT NULL,
  `statusMessage` TEXT,
  `isBacksync` INTEGER DEFAULT 0 NOT NULL,
  `objectName` TEXT,
  `attempt` INTEGER NOT NULL DEFAULT 0
);

INSERT INTO tasks_new(
  `id`,
  `createdAt`,
  `parentId`,
  `objectType`,
  `action`,
  `masterCustomerId`,
  `masterSubscriptionId`,
  `masterServicePlanId`,
  `oldValues`,
  `newValues`,
  `nodeId`,
  `status`,
  `statusMessage`,
  `isBacksync`,
  `objectName`,
  `attempt`
)

  SELECT
  `id`,
  `createDate`,
  `parentId`,
  `objectType`,
  `action`,
  `masterCustomerId`,
  `masterSubscriptionId`,
  `masterServicePlanId`,
  `oldValues`,
  `newValues`,
  `nodeId`,
  `status`,
  `statusMessage`,
  `isBacksync`,
  `objectName`,
  `attempt`
   FROM tasks;

DROP TABLE tasks;

ALTER TABLE tasks_new RENAME TO tasks;

PRAGMA foreign_keys = ON;
