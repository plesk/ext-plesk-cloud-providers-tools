PRAGMA foreign_keys = OFF;

CREATE TABLE `nodes_new` (
  `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
  `ipAddress` TEXT UNIQUE NOT NULL,
  `secretKey` TEXT,
  `description` TEXT,
  `status` TEXT DEFAULT 'disabled' NOT NULL,
  `lastProcessedEventId` INTEGER
);

INSERT INTO nodes_new(`id`, `ipAddress`, `secretKey`, `description`, `lastProcessedEventId`, `status`)
  SELECT `id`, `ipAddress`, `secretKey`, `description`, `lastProcessedEventId`, CASE `status` WHEN 0 then 'active' ELSE 'disabled' END
  FROM nodes;

DROP TABLE nodes;

ALTER TABLE nodes_new RENAME TO nodes;

PRAGMA foreign_keys = ON;
