PRAGMA foreign_keys = OFF;

DROP TABLE IF EXISTS `tokens`;

CREATE TABLE IF NOT EXISTS `tokens` (
  `nodeId` INTEGER REFERENCES nodes(id),
  `token` TEXT NOT NULL,
  `masterToken` TEXT NOT NULL,
  `login` TEXT NOT NULL,
  `clientIpAddress` TEXT NOT NULL,
   PRIMARY KEY (`nodeId`, `token`)
);

PRAGMA foreign_keys = ON;
