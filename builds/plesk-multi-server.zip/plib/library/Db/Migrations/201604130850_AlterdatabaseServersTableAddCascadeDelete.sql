PRAGMA foreign_keys = OFF;

CREATE TABLE IF NOT EXISTS `databaseServers_new` (
  `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
  `slaveNodeId` INTEGER REFERENCES nodes(id) ON DELETE CASCADE,
  `masterId` INTEGER NOT NULL,
  `slaveId` INTEGER NOT NULL
);

INSERT INTO databaseServers_new(`id`, `slaveNodeId`, `masterId`, `slaveId`)
  SELECT `id`, `slaveNodeId`, `masterId`, `slaveId`
  FROM databaseServers;

DROP TABLE databaseServers;

ALTER TABLE databaseServers_new RENAME TO databaseServers;

PRAGMA foreign_keys = ON;
