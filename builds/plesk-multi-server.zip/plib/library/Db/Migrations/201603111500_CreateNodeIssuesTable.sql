CREATE TABLE IF NOT EXISTS `nodeIssues` (
  `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
  `slaveNodeId` INTEGER REFERENCES nodes(id) ON DELETE CASCADE,
  `createdAt` DATETIME NOT NULL DEFAULT (strftime('%s','now')),
  `code` TEXT NOT NULL,
  `message` TEXT
);
