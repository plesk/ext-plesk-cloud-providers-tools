DROP TABLE IF EXISTS `taskLogEntries`;
CREATE TABLE IF NOT EXISTS `taskLogEntries` (
  `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
  `taskRunId` INTEGER NOT NULL REFERENCES taskRuns(id) ON DELETE CASCADE,
  `timestamp` TEXT NOT NULL,
  `message` TEXT,
  `priority` INTEGER NOT NULL,
  `priorityName` TEXT
);
