ALTER TABLE `ipAddresses` ADD COLUMN `type` TEXT CHECK(`type` IN ('exclusive','shared')) NOT NULL DEFAULT 'shared';
ALTER TABLE `ipAddresses` ADD COLUMN `version` TEXT CHECK(`version` IN ('ipv4','ipv6')) NOT NULL DEFAULT 'ipv4';
