ALTER TABLE `nodes` ADD COLUMN `description` TEXT;
