PRAGMA foreign_keys = OFF;

CREATE TABLE `tasks_new` (
  `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
  `createDate` TEXT NOT NULL DEFAULT (strftime('%s','now')),
  `parentId` INTEGER REFERENCES tasks_new(id) ON DELETE SET NULL,
  `objectType` TEXT NOT NULL,
  `action` TEXT NOT NULL,
  `masterCustomerId` INTEGER,
  `masterSubscriptionId` INTEGER,
  `masterServicePlanId` INTEGER,
  `oldValues` TEXT,
  `newValues` TEXT,
  `nodeId` INTEGER REFERENCES nodes(id) ON DELETE CASCADE,
  `status` INTEGER DEFAULT 0 NOT NULL,
  `statusMessage` TEXT,
  `isBacksync` INTEGER DEFAULT 0 NOT NULL
);
INSERT INTO `tasks_new`
  SELECT
    `id`,
    `createDate`,
    `parentId`,
    `objectType`,
    `action`,
    `masterCustomerId`,
    `masterSubscriptionId`,
    `masterServicePlanId`,
    `oldValues`,
    `newValues`,
    `nodeId`,
    `status`,
    `statusMessage`,
    `isBacksync`
  FROM `tasks`;
DROP TABLE `tasks`;
ALTER TABLE `tasks_new` RENAME TO `tasks`;

CREATE TABLE `taskLogEntries_new` (
`id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
  `taskId` INTEGER NOT NULL REFERENCES tasks(id) ON DELETE CASCADE ,
  `timestamp` TEXT NOT NULL,
  `message` TEXT,
  `priority` INTEGER NOT NULL,
  `priorityName` TEXT
);
INSERT INTO `taskLogEntries_new`
  SELECT `id`, `taskId`, `timestamp`, `message`, `priority`, `priorityName`
  FROM `taskLogEntries`;
DROP TABLE `taskLogEntries`;
ALTER TABLE `taskLogEntries_new` RENAME TO `taskLogEntries`;

PRAGMA foreign_keys = ON;
