CREATE TEMPORARY TABLE `nodes_tmp` (`id`, `ipAddress`, `secretKey`, `description`);
INSERT INTO `nodes_tmp` SELECT `id`, `ipAddress`, `secretKey`, `description` FROM `nodes`;
DROP TABLE `nodes`;
CREATE TABLE `nodes` (
  `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
  `ipAddress` TEXT UNIQUE NOT NULL,
  `secretKey` TEXT,
  `description` TEXT
);
INSERT INTO `nodes` SELECT `id`, `ipAddress`, `secretKey`, `description` FROM `nodes_tmp`;
DROP TABLE `nodes_tmp`;
