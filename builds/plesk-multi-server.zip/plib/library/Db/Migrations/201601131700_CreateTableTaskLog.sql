CREATE TABLE IF NOT EXISTS `taskLog` (
  `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
  `taskId` INTEGER NOT NULL REFERENCES tasks(id),
  `timestamp` TEXT NOT NULL,
  `message` TEXT,
  `priority` INTEGER NOT NULL,
  `priorityName` TEXT
);
