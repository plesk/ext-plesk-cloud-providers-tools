CREATE TABLE IF NOT EXISTS `sites` (
  `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
  `slaveNodeId` INTEGER REFERENCES nodes(id),
  `masterId` INTEGER NOT NULL,
  `slaveId` INTEGER NOT NULL,
  `masterGuid` TEXT NOT NULL,
  `slaveGuid` TEXT NOT NULL,
  `subscriptionId` INTEGER REFERENCES subscriptions(id),
  `name` TEXT
);
