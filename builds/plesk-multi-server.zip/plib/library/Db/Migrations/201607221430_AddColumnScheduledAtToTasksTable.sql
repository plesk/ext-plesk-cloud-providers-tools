ALTER TABLE `tasks` ADD COLUMN `scheduledAt` DATETIME DEFAULT NULL;
update `tasks` set `scheduledAt` = `createdAt`;
