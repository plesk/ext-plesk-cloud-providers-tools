CREATE TABLE IF NOT EXISTS `tokens` (
  `nodeId` INTEGER REFERENCES nodes(id),
  `token` TEXT NOT NULL,
  `login` TEXT NOT NULL,
  `clientIpAddress` TEXT NOT NULL,
   PRIMARY KEY (`nodeId`, `token`)
);
