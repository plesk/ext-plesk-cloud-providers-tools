PRAGMA foreign_keys = OFF;

CREATE TABLE IF NOT EXISTS `sites_new` (
  `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
  `slaveNodeId` INTEGER REFERENCES nodes(id) ON DELETE CASCADE,
  `masterId` INTEGER NOT NULL,
  `slaveId` INTEGER NOT NULL,
  `masterGuid` TEXT NOT NULL,
  `slaveGuid` TEXT NOT NULL,
  `subscriptionId` INTEGER REFERENCES subscriptions(id) ON DELETE CASCADE,
  `name` TEXT
);

INSERT INTO sites_new(`id`, `slaveNodeId`, `masterId`, `slaveId`, `masterGuid`, `slaveGuid`, `subscriptionId`, `name`)
  SELECT `id`, `slaveNodeId`, `masterId`, `slaveId`, `masterGuid`, `slaveGuid`, `subscriptionId`, `name`
  FROM sites;

DROP TABLE sites;

ALTER TABLE sites_new RENAME TO sites;

PRAGMA foreign_keys = ON;
