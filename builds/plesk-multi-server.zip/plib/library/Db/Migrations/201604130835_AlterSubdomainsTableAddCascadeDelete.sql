PRAGMA foreign_keys = OFF;

CREATE TABLE IF NOT EXISTS `subdomains_new` (
  `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
  `slaveNodeId` INTEGER REFERENCES nodes(id) ON DELETE CASCADE,
  `masterId` INTEGER NOT NULL,
  `slaveId` INTEGER NOT NULL,
  `fullName` TEXT NOT NULL
);

INSERT INTO subdomains_new(`id`, `slaveNodeId`, `masterId`, `slaveId`, `fullName`)
  SELECT `id`, `slaveNodeId`, `masterId`, `slaveId`, `fullName`
  FROM subdomains;

DROP TABLE subdomains;

ALTER TABLE subdomains_new RENAME TO subdomains;

PRAGMA foreign_keys = ON;
