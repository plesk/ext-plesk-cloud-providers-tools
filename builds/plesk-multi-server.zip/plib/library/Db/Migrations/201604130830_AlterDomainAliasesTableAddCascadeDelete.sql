PRAGMA foreign_keys = OFF;

CREATE TABLE IF NOT EXISTS `domainAliases_new` (
  `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
  `slaveNodeId` INTEGER REFERENCES nodes(id) ON DELETE CASCADE,
  `masterId` INTEGER NOT NULL,
  `slaveId` INTEGER NOT NULL,
  `name` TEXT NOT NULL
);

INSERT INTO domainAliases_new(`id`, `slaveNodeId`, `masterId`, `slaveId`, `name`)
  SELECT `id`, `slaveNodeId`, `masterId`, `slaveId`, `name`
  FROM domainAliases;

DROP TABLE domainAliases;

ALTER TABLE domainAliases_new RENAME TO domainAliases;

PRAGMA foreign_keys = ON;
