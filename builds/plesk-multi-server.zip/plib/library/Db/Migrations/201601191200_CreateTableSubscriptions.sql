CREATE TABLE IF NOT EXISTS `subscriptions` (
  `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
  `slaveNodeId` INTEGER REFERENCES nodes(id),
  `masterId` INTEGER NOT NULL,
  `masterGuid` TEXT NOT NULL,
  `slaveId` INTEGER NOT NULL,
  `slaveGuid` TEXT NOT NULL,
  `customerId` INTEGER REFERENCES customers(id)
);
