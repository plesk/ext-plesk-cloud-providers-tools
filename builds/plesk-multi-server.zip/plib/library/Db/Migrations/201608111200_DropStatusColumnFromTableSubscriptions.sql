PRAGMA foreign_keys = OFF;

CREATE TABLE IF NOT EXISTS `subscriptions_new` (
  `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
  `slaveNodeId` INTEGER REFERENCES nodes(id),
  `masterId` INTEGER NOT NULL,
  `masterGuid` TEXT NOT NULL,
  `slaveId` INTEGER NOT NULL,
  `slaveGuid` TEXT NOT NULL,
  `customerId` INTEGER REFERENCES customers(id)
);

INSERT INTO subscriptions_new(
    `id`,
    `slaveNodeId`,
    `masterId`,
    `masterGuid`,
    `slaveId`,
    `slaveGuid`,
    `customerId`
  ) SELECT
    `id`,
    `slaveNodeId`,
    `masterId`,
    `masterGuid`,
    `slaveId`,
    `slaveGuid`,
    `customerId`
  FROM subscriptions;

DROP TABLE subscriptions;

ALTER TABLE subscriptions_new RENAME TO subscriptions;

PRAGMA foreign_keys = ON;
