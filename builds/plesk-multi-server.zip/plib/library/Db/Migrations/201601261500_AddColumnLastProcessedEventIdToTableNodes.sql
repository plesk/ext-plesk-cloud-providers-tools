ALTER TABLE `nodes` ADD COLUMN `lastProcessedEventId` INTEGER;
