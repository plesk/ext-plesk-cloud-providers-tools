PRAGMA foreign_keys = OFF;

CREATE TABLE IF NOT EXISTS `servicePlans_new` (
  `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
  `slaveNodeId` INTEGER REFERENCES nodes(id) ON DELETE CASCADE,
  `masterId` INTEGER NOT NULL,
  `masterGuid` TEXT NOT NULL,
  `slaveId` INTEGER NOT NULL,
  `slaveGuid` TEXT NOT NULL
);

INSERT INTO servicePlans_new(`id`, `slaveNodeId`, `masterId`, `masterGuid`, `slaveId`, `slaveGuid`)
  SELECT `id`, `slaveNodeId`, `masterId`, `masterGuid`, `slaveId`, `slaveGuid`
  FROM servicePlans;

DROP TABLE servicePlans;

ALTER TABLE servicePlans_new RENAME TO servicePlans;

PRAGMA foreign_keys = ON;
