ALTER TABLE `customers` ADD COLUMN `login` TEXT;
