ALTER TABLE `taskLog` RENAME TO `taskLogEntries`;
