CREATE TABLE IF NOT EXISTS `version` (
  `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
  `dbVersion` TEXT NOT NULL
);
INSERT INTO `version` (`dbVersion`) VALUES ('201703031600');

CREATE TABLE IF NOT EXISTS `nodes` (
  `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
  `ipAddress` TEXT UNIQUE NOT NULL,
  `hostname` TEXT DEFAULT '' NOT NULL,
  `navigateByHostname` INTEGER DEFAULT 0 NOT NULL,
  `secretKey` TEXT,
  `description` TEXT,
  `status` TEXT DEFAULT 'disabled' NOT NULL,
  `lastProcessedEventId` INTEGER,
  `isVps` INTEGER DEFAULT 0 NOT NULL,
  `pleskVersion` TEXT DEFAULT '' NOT NULL,
  `installedPleskPatch` TEXT DEFAULT '' NOT NULL,
  `availablePleskPatch` TEXT DEFAULT '' NOT NULL,
  `moduleVersion` TEXT DEFAULT '' NOT NULL
);
CREATE TABLE IF NOT EXISTS `tasks` (
  `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
  `createdAt` DATETIME NOT NULL DEFAULT (strftime('%s','now')),
  `updatedAt` DATETIME NOT NULL DEFAULT (strftime('%s','now')),
  `parentId` INTEGER REFERENCES tasks(id) ON DELETE SET NULL,
  `objectType` TEXT NOT NULL,
  `action` TEXT NOT NULL,
  `masterCustomerId` INTEGER,
  `masterSubscriptionId` INTEGER,
  `masterServicePlanId` INTEGER,
  `oldValues` TEXT,
  `newValues` TEXT,
  `nodeId` INTEGER REFERENCES nodes(id) ON DELETE CASCADE,
  `status` INTEGER DEFAULT 0 NOT NULL,
  `statusMessage` TEXT,
  `isBacksync` INTEGER DEFAULT 0 NOT NULL,
  `objectName` TEXT,
  `attempt` INTEGER NOT NULL DEFAULT 0,
  `workerId` INTEGER,
  `scheduledAt` DATETIME DEFAULT NULL
);
CREATE TABLE IF NOT EXISTS `taskLogEntries` (
  `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
  `timestamp` TEXT NOT NULL,
  `message` TEXT,
  `priority` INTEGER NOT NULL,
  `priorityName` TEXT,
  `taskId` INTEGER NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
  `attempt` INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS `customers` (
  `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
  `slaveNodeId` INTEGER REFERENCES nodes(id) ON DELETE CASCADE,
  `masterId` INTEGER NOT NULL,
  `masterGuid` TEXT NOT NULL,
  `slaveId` INTEGER NOT NULL,
  `slaveGuid` TEXT NOT NULL,
  `login` TEXT
);
CREATE TABLE IF NOT EXISTS `servicePlans` (
  `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
  `slaveNodeId` INTEGER REFERENCES nodes(id) ON DELETE CASCADE,
  `masterId` INTEGER NOT NULL,
  `masterGuid` TEXT NOT NULL,
  `slaveId` INTEGER NOT NULL,
  `slaveGuid` TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS `subscriptions` (
  `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
  `slaveNodeId` INTEGER REFERENCES nodes(id),
  `masterId` INTEGER NOT NULL,
  `masterGuid` TEXT NOT NULL,
  `slaveId` INTEGER NOT NULL,
  `slaveGuid` TEXT NOT NULL,
  `customerId` INTEGER REFERENCES customers(id)
);
CREATE TABLE IF NOT EXISTS `domainAliases` (
  `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
  `slaveNodeId` INTEGER REFERENCES nodes(id) ON DELETE CASCADE,
  `masterId` INTEGER NOT NULL,
  `slaveId` INTEGER NOT NULL,
  `name` TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS `subdomains` (
  `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
  `slaveNodeId` INTEGER REFERENCES nodes(id) ON DELETE CASCADE,
  `masterId` INTEGER NOT NULL,
  `slaveId` INTEGER NOT NULL,
  `fullName` TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS `sites` (
  `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
  `slaveNodeId` INTEGER REFERENCES nodes(id) ON DELETE CASCADE,
  `masterId` INTEGER NOT NULL,
  `slaveId` INTEGER NOT NULL,
  `masterGuid` TEXT NOT NULL,
  `slaveGuid` TEXT NOT NULL,
  `subscriptionId` INTEGER REFERENCES subscriptions(id) ON DELETE CASCADE,
  `name` TEXT
);
CREATE TABLE IF NOT EXISTS `databaseServers` (
  `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
  `slaveNodeId` INTEGER REFERENCES nodes(id) ON DELETE CASCADE,
  `masterId` INTEGER NOT NULL,
  `slaveId` INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS `nodeIssues` (
  `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
  `slaveNodeId` INTEGER REFERENCES nodes(id) ON DELETE CASCADE,
  `createdAt` DATETIME NOT NULL DEFAULT (strftime('%s','now')),
  `code` TEXT NOT NULL,
  `message` TEXT,
  `prevNodeStatus` TEXT DEFAULT '' NOT NULL,
  `sentToAdmin` INTEGER DEFAULT 0 NOT NULL
);
CREATE TABLE IF NOT EXISTS `tokens` (
  `nodeId` INTEGER REFERENCES nodes(id) ON DELETE CASCADE,
  `token` TEXT NOT NULL,
  `masterToken` TEXT NOT NULL,
  `login` TEXT NOT NULL,
  `clientIpAddress` TEXT NOT NULL,
   PRIMARY KEY (`nodeId`, `token`)
);
CREATE TABLE IF NOT EXISTS `ipAddresses` (
  `ipAddress` TEXT NOT NULL PRIMARY KEY,
  `nodeId` INTEGER REFERENCES nodes(id) ON DELETE CASCADE,
  `type` TEXT CHECK(`type` IN ('exclusive','shared')) NOT NULL DEFAULT 'shared',
  `version` TEXT CHECK(`version` IN ('ipv4','ipv6')) NOT NULL DEFAULT 'ipv4',
  `isWebHosting` INTEGER DEFAULT 0 NOT NULL
);
CREATE TABLE IF NOT EXISTS `subscriptionIpAddresses` (
  `subscriptionId` INTEGER REFERENCES subscriptions(id) ON DELETE CASCADE,
  `ipAddress` TEXT NOT NULL REFERENCES ipAddresses(ipAddress) ON DELETE CASCADE,
   PRIMARY KEY (`subscriptionId`, `ipAddress`)
);
CREATE TABLE IF NOT EXISTS `dnsSlaves` (
  `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
  `ip` TEXT NOT NULL,
  `port` INTEGER DEFAULT 22 NOT NULL,
  `rndcKey` TEXT DEFAULT NULL,
  `userName` TEXT NOT NULL,
  `domainName` TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS `stats` (
  `subscriptionId` INTEGER REFERENCES subscriptions(id) ON DELETE CASCADE,
  `collectedAt` DATETIME NOT NULL DEFAULT (strftime('%s','now')),
  `realSize` INTEGER,
  `traffic` INTEGER,
  `subdomains` INTEGER,
  `aliases` INTEGER,
  `webUsers` INTEGER,
  `mailboxes` INTEGER,
  `mailRedirects` INTEGER,
  `mailGroups` INTEGER,
  `mailResponses` INTEGER,
  `mailLists` INTEGER,
  `databases` INTEGER,
  `webApps` INTEGER,
  `trafficPrevDay` INTEGER,
  `domains` INTEGER,
  `sites` INTEGER,
  `duHttpDocs` INTEGER,
  `duHttpsDocs` INTEGER,
  `duSubdomains` INTEGER,
  `duWebUsers` INTEGER,
  `duAnonFtp` INTEGER,
  `duLogs` INTEGER,
  `duDatabases` INTEGER,
  `duMailboxes` INTEGER,
  `duWebApps` INTEGER,
  `duMailLists` INTEGER,
  `duDomainDumps` INTEGER,
  `duConfigs` INTEGER,
  `duChroot` INTEGER,
  PRIMARY KEY (`subscriptionId`)
);

CREATE TABLE IF NOT EXISTS `trafficStats` (
  `subscriptionId` INTEGER REFERENCES subscriptions(id) ON DELETE CASCADE,
  `collectedAt` DATETIME NOT NULL DEFAULT (strftime('%s','now')),
  `date` TEXT,
  `httpIn` INTEGER,
  `httpOut` INTEGER,
  `ftpIn` INTEGER,
  `ftpOut` INTEGER,
  `smtpIn` INTEGER,
  `smtpOut` INTEGER,
  `pop3ImapIn` INTEGER,
  `pop3ImapOut` INTEGER,
  PRIMARY KEY (`subscriptionId`, `date`)
);
CREATE TABLE IF NOT EXISTS `adminAliases` (
  `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
  `slaveNodeId` INTEGER REFERENCES nodes(id) ON DELETE CASCADE,
  `login` TEXT
);

CREATE TABLE IF NOT EXISTS balancerParameters (
  `subscriptionMasterId` INTEGER NOT NULL PRIMARY KEY,
  `taskId` INTEGER REFERENCES tasks(id) ON DELETE CASCADE,
  `ipv4Type` TEXT CHECK(`ipv4Type` IN ('none','exclusive','shared')) NOT NULL DEFAULT 'none',
  `ipv6Type` TEXT CHECK(`ipv6Type` IN ('none','exclusive','shared')) NOT NULL DEFAULT 'none'
);
