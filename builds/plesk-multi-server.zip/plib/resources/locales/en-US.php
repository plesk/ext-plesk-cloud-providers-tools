<?php
// Copyright 1999-2017. Parallels IP Holdings GmbH. All Rights Reserved.

$messages = [
    // controller messages
    'controllers.customer.changePassword.pageTitle' => 'Change Password',
    'controllers.node.list.pageTitle' => 'Plesk Multi Server',
    'controllers.node.list.title' => 'Service Nodes',
    'controllers.node.list.pageHint' => 'This is where you manage service nodes connected to the management node.',
    'controllers.node.add.pageTitle' => 'Add Service Node',
    'controllers.node.add.pageHint' => 'This is where you can specify the details about new service nodes.',
    'controllers.node.add1.pageTitle' => 'Specify IP Addresses for new %%nodeHost%% node',
    'controllers.node.add.successMsg' => 'The service node was successfully registered.',
    'controllers.node.add.license.invalid' => 'The service node license has no Plesk Multi Server support.',
    'controllers.node.add.activate.warning' => 'Failed to activate the node.',
    'controllers.node.add.dns.slave.instructions' => 'Centralized DNS management is enabled. You need to change DNS slave configurations to make the new Plesk Multi Server node act as the DNS master for all DNS slave servers.',
    'controllers.node.view.pageTitle' => 'Service Node %%node%%',
    'controllers.node.view.activateButtonTitle' => 'Activate',
    'controllers.node.view.activateButtonDesc' => 'Activate the node.',
    'controllers.node.view.confirm.activate.text' => 'Do you want to activate this node?',
    'controllers.node.view.disableButtonTitle' => 'Deactivate',
    'controllers.node.view.disableButtonDesc' => 'Deactivate the node.',
    'controllers.node.view.confirm.disable.text' => 'Do you want to deactivate this node?',
    'controllers.node.view.maintenanceButtonTitle' => 'Maintenance',
    'controllers.node.view.maintenanceButtonDesc' => 'Switch to maintenance mode.',
    'controllers.node.view.confirm.maintenance.text' => 'Do you want to switch this node to maintenance mode?',
    'controllers.node.edit.pageTitle' => 'Edit Service Node %%node%%',
    'controllers.node.edit.successMsg' => 'The service node was successfully edited.',
    'controllers.node.edit.unknownNode' => 'Unknown node',
    'controllers.node.edit.description' => 'Edit description',
    'controllers.node.edit.title' => 'Edit service node',
    'controllers.node.edit.title.waitMessage' => 'Please wait',
    'controllers.node.edit.updatedMessage' => 'The node settings were updated.',
    'controllers.node.delete.successMsg' => 'Please note that deleting the node takes some time.',
    'controllers.node.delete.errorMsg' => 'Some of the selected nodes were not unregistered:',
    'controllers.node.delete.errorMsgReasonSubscriptions' => 'There are subscriptions provisioned to the service node "%%node%%"',
    'controllers.node.insert.errorMsgReasonServicePlans' => 'Failed to create a service plan on the node: "%%error%%"',
    'controllers.node.change.status.successMsg' => 'The status was changed for %%count%% node(s).',
    'controllers.node.change.status.nodeWrongStatus' => 'The node %%nodeIp%% has status \'%%status%%\' and cannot be activated.',
    'controllers.node.change.status.errorMsg' => 'An error occurred while changing the node\'s status.',
    'controllers.node.license.invalid' => 'The Plesk Multi Server license has expired or is invalid. The action is not available.',
    'component.license.invalid.customer.warning' => 'The Plesk Multi Server license has expired or is invalid. Please contact your hosting provider.',

    'controllers.node.active.successMsg' => 'Please note that activating the node takes some time.',
    'controllers.node.disabled.successMsg' => 'The node was disabled.',
    'controllers.node.maintenance.successMsg' => 'The node was switched to maintenance mode.',

    'components.form.customerChangePassword.login.title' => 'Username',
    'components.form.customerChangePassword.oldPassword.title' => 'Old Password',
    'components.form.customerChangePassword.oldPassword.emptyError' => 'You need to provide the old password.',
    'components.form.customerChangePassword.oldPassword.incorrectError' => 'The old password is incorrect. Please try again.',
    'components.form.customerChangePassword.newPassword.title' => 'New Password',
    'components.form.customerChangePassword.newPassword.emptyError' => 'You need to provide a new password.',
    'components.form.customerChangePassword.newPasswordConfirmation.title' => 'Confirm New Password',
    'components.form.customerChangePassword.newPasswordConfirmation.emptyError' => 'You need to confirm the new password.',
    'components.form.node.issues.label' => 'Issues occurred',
    'components.form.node.issue.invalid-secret-key.label' => 'Secret key',
    'components.form.node.issue.invalid-secret-key.title' => 'The secret key is expired or invalid.',
    'components.form.node.issue.invalid-secret-key.button.title' => 'Reissue Secret Key',
    'components.form.node.issue.invalid-secret-key.description' => 'Reissue the secret key from a service node.',
    'components.form.node.issue.sync-error.label' => 'Synchronization status',
    'components.form.node.issue.sync-error.title' => 'The node is not synced with the management node.',
    'components.form.node.issue.unsupported-protocol-version.label' => 'XML API protocol version',
    'components.form.node.issue.unsupported-protocol-version.title' => 'Node XML API protocol version is unsupported',
    'components.form.node.issue.incompatible-node.label' => 'Nodes incompatibility',
    'components.form.node.issue.incompatible-node.title' => 'The node is incompatible with the management node.',
    'components.form.node.issue.web-configuration-error.label' => 'Web configuration status',
    'components.form.node.issue.web-configuration-error.title' => 'The web server configuration has errors.',
    'components.form.node.issue.web-configuration-error.node.button.title' => 'Resolve',
    'components.form.node.issue.recheck.node.button.title' => 'Re-check Node',
    'components.form.node.issue.recheck.node.description' => 'Re-check the nodes for errors.',

    'controllers.node.reissueKey.form.title' => 'Reissue Node Secret Key',
    'controllers.node.reissueKey.successMsg' => 'The key was successfully received by the node %%nodeIp%%',
    'controllers.node.reissueKey.errorMsg' => 'An error occurred while retrieving keys.',
    'controllers.node.recheck.successMsg' => 'The node passed validation and was activated.',
    'controllers.node.recheck.failedMsg' => 'The node has not passed validation.',

    'controllers.task.list.pageTitle' => 'Provisioning Tasks',
    'controllers.task.list.title' => 'Provisioning Tasks',
    'controllers.task.list.pageHint' => 'This is where you view information about provisioning tasks.',
    'controllers.task.delete.successMsg' => 'The selected tasks were removed.',
    'controllers.task.delete.errorMsg' => 'Some of the selected tasks were not removed:',
    'controllers.task.view.pageTitle' => '%%task%%: %%objectName%%',
    'controllers.task.view.unknownTask' => 'Unknown task',
    'controllers.task.view.restartButtonTitle' => 'Rerun',
    'controllers.task.view.restartButtonDesc' => 'Rerun the task',
    'controllers.task.view.reBalanceButtonTitle' => 'Rebalance',
    'controllers.task.view.reBalanceButtonDesc' => 'Rebalance the service node for subscription creation and rerun this task.',
    'controllers.task.restart.success' => 'The task "%%taskName%%" (ID: %%taskId%%) was rerun.',
    'controllers.task.restart.successMsg' => '%%count%% selected failed tasks were successfully rerun.',
    'controllers.task.restart.errorMsg' => 'Some of the selected failed tasks were not rerun.',
    'controllers.task.re-balance.errorMsg' => 'Unable to rebalance the service node for subscription creation.',

    'controllers.subscription.list.pageTitle' => 'Select Subscription',
    'controllers.subscription.list.stat-hint.title' => 'Subscription summary',
    'controllers.subscription.list.stat-hint.wait' => 'Please wait',
    'controllers.subscription.list.pageHint' => 'Select one of your subscription to start managing its websites.',
    'controllers.subscription.list.noSubscriptions' => 'Your account has no subscriptions; therefore, no operations are available. Please contact your service provider for assistance with subscribing to services.',
    'controllers.subscription.stat-hint.limits.unlimited.title' => 'Unlimited',
    'controllers.subscription.stat-hint.limits.domains.title' => 'Domains',
    'controllers.subscription.stat-hint.limits.subdomains.title' => 'Subdomains',
    'controllers.subscription.stat-hint.limits.aliases.title' => 'Domain aliases',
    'controllers.subscription.stat-hint.limits.sites.title' => 'Sites',
    'controllers.subscription.stat-hint.limits.realSize.title' => 'Disk space',
    'controllers.subscription.stat-hint.limits.traffic.title' => 'Traffic',
    'controllers.subscription.stat-hint.limits.databases.title' => 'Databases',
    'controllers.subscription.stat-hint.limits.mailboxes.title' => 'Mailboxes',
    'controllers.subscription.stat-hint.limits.mailLists.title' => 'Mailing lists',
    'controllers.subscription.stat-hint.limits.used.of' => '%%count%% used of %%limit%%',
    'controllers.subscription.stat-hint.limits.perMonth.suffix' => '/month',
    'controllers.subscription.stat-hint.limits.b.title' => 'B',
    'controllers.subscription.stat-hint.limits.kb.title' => 'KB',
    'controllers.subscription.stat-hint.limits.mb.title' => 'MB',
    'controllers.subscription.stat-hint.limits.gb.title' => 'GB',
    'controllers.subscription.stat-hint.limits.tb.title' => 'TB',

    'controllers.sync.mailServerSettings.sync.start' => 'The Mail Server settings synchronization started',
    'controllers.sync.mailServerSettings.sync.notChanged' => 'The Mail Server settings are not changed',
    'controllers.sync.dnsTemplate.sync.start' => 'The DNS template sync process has started.',
    'controllers.sync.dnsTemplate.sync.notChanged' => 'The DNS template was not changed.',

    'controllers.redirect.inactiveNode' => 'The node is not active.',
    'controllers.redirect.unknownNode' => 'Unknown node.',
    'controllers.redirect.unknownSubscription' => 'Subscription not found on service node.',
    'controllers.redirect.unknownSite' => 'Site not found on service node.',
    'controllers.redirect.unknownSubdomain' => 'Subdomain not found on service node.',
    'controllers.redirect.unknownDomainAlias' => 'Domain alias was not found on service node.',
    'controllers.redirect.nodes.list.pageTitle' => 'Select a Node',
    'controllers.redirect.nodes.list.master.node.record' => '%%nodeTitle%% (management node)',
    'controllers.redirect.node.maintenance.pageTitle' => 'The node is under maintenance. Please visit later.',
    'controllers.redirect.withMessage.defaultMessage' => 'Some error occurred.',
    'controllers.redirect.backToServiceNode.subscriptionUnknown' => 'Select a subscription to return to the service node.',

    'controllers.dns-slave.list.pageHint' => 'This is where you manage DNS slave servers added to your Plesk Multi Server.',
    'controllers.dns-slave.list.pageTitle' => 'DNS Slave Nodes',
    'controllers.dns-slave.list.title' => 'DNS slave nodes',
    'controllers.dns-slave.add.pageTitle' => 'Add DNS slave node',
    'controllers.dns-slave.add.successMsg' => 'DNS slave was successfully added.',
    'controllers.dns-slave.edit.pageTitle' => 'Edit DNS slave %%dns-slave-ip%%',
    'controllers.dns-slave.edit.unknownNode' => 'Failed to get DNS slave',
    'controllers.dns-slave.edit.updatedMessage' => 'DNS slave server updated.',
    'controllers.dns-slave.delete.successMsg' => 'The selected DNS slave nodes were removed.',
    'controllers.dns-slave.delete.errorMsg' => 'Failed to delete the selected DNS slave nodes.',
    'controllers.dns-slave.howto.title' => 'How to Set Up Centralized DNS Management for Plesk Multi Server',

    'controllers.settings.index.pageTitle' => 'Plesk Multi Server Settings',
    'controllers.settings.save.successMsg' => 'The settings were successfully updated.',
    'controllers.settings.auto.template.manage.not.enabled' => 'Automated DNS template management is not enabled. You need to manage DNS records of the template manually.',

    // view list messages
    'components.list.nodes.nodeColumn.title' => 'Node',
    'components.list.nodes.statusColumn.title' => 'Status',
    'components.list.nodes.subscriptionsCountColumn' => 'Subscriptions',
    'components.list.nodes.descriptionColumn' => 'Description',
    'components.list.nodes.pleskVersionColumn' => 'Plesk version',
    'components.list.nodes.addButtonTitle' => 'Add Node',
    'components.list.nodes.addButtonDesc' => 'Add service node.',
    'components.list.nodes.removeButtonTitle' => 'Remove',
    'components.list.nodes.removeButtonDesc' => 'Remove the selected service nodes.',
    'components.list.nodes.confirmOnDelete' => 'Do you want to unregister the selected service nodes?',
    'components.list.nodes.maintenanceButtonTitle' => 'Maintenance',
    'components.list.nodes.maintenanceButtonDesc' => 'Switch the selected nodes to maintenance mode.',
    'components.list.nodes.confirmOnMaintenance' => 'Do you want to switch the selected nodes to maintenance mode?',
    'components.list.nodes.activateButtonTitle' => 'Activate',
    'components.list.nodes.activateButtonDesc' => 'Activate the selected nodes.',
    'components.list.nodes.confirmOnActivate' => 'Do you want to activate the selected nodes?',
    'components.list.nodes.deactivateButtonTitle' => 'Deactivate',
    'components.list.nodes.deactivateButtonDesc' => 'Deactivate the selected nodes.',
    'components.list.nodes.confirmOnDeactivate' => 'Do you want to deactivate the selected nodes?',
    'components.list.nodes.redirect' => 'Manage Node',
    'components.list.nodes.recheck' => 'Re-Check',
    'components.list.nodes.noIssuesMessage' => 'No issues',
    'components.list.nodes.issuesMessage' => '%%count%% issue(s)',
    'components.list.nodes.isVps' => 'VPS node',
    'components.list.nodes.settingsButtonTitle' => 'Plesk Multi Server Settings',
    'components.list.nodes.settingsButtonDesc' => 'Configure Plesk Multi Server.',
    'components.list.nodes.status.popup.title' => 'Status Description',
    'components.list.nodes.status.popup.wait' => 'Please wait...',
    'components.nodes.list.popup.status.description' => 'The node status is <b>%%status%%</b>',
    'components.nodes.list.popup.issues.title' => 'Issues occurred:',

    'components.list.redirect.nodes.ipAddressColumn' => 'Node',

    'components.list.tasks.idColumn' => 'ID',
    'components.list.tasks.statusColumn' => 'Status',
    'components.list.tasks.statusColumn.filter.title' => 'Status',
    'components.list.tasks.statusMessageColumn' => 'Status message',
    'components.list.tasks.statusMessageColumn.filter.title' => 'Status message',
    'components.list.tasks.statusMessage.popup.title' => 'Failed Task Details',
    'components.list.tasks.statusMessage.popup.wait' => 'Please wait...',
    'components.list.tasks.blockedMessage.popup.title' => 'Blocked Task Details',
    'components.list.tasks.blockedMessage.popup.wait' => 'Please wait...',
    'components.list.tasks.blockedMessage.popup.messageWithLink' => 'Blocked by <a href="%%link%%">#%%taskId%%. %%taskName%% (%%taskObject%%)</a>',
    'components.list.tasks.awaitingMessage.popup.title' => 'Pending Task Details',
    'components.list.tasks.awaitingMessage.popup.wait' => 'Please wait...',
    'components.list.tasks.awaitingMessage.popup.messageWithLink' => 'The task is awaiting <a href="%%link%%">#%%taskId%%. %%taskName%%</a>',
    'components.list.tasks.actionColumn' => 'Action',
    'components.list.tasks.actionColumn.filter.title' => 'Action',
    'components.list.tasks.nodeColumn' => 'Service Node',
    'components.list.tasks.nodeColumn.filter.title' => 'Node',
    'components.list.tasks.nodeColumn.filter.any.title' => 'Any Node',
    'components.list.tasks.nodeColumn.filter.none.title' => 'No Node',
    'components.list.tasks.objectNameColumn' => 'Object',
    'components.list.tasks.objectColumn.filter.title' => 'Object',
    'components.list.tasks.createTimeColumn' => 'Creation Time',
    'components.list.tasks.scheduledAtColumn' => 'Scheduled Time',
    'components.list.tasks.removeButtonTitle' => 'Remove',
    'components.list.tasks.removeButtonDesc' => 'Remove the selected tasks.',
    'components.list.tasks.refreshButtonTitle' => 'Refresh',
    'components.list.tasks.refreshButtonDesc' => 'Refresh the list of tasks.',
    'components.list.tasks.confirmOnDelete' => 'Do you want to remove the selected tasks?',
    'components.list.tasks.restartButtonTitle' => 'Rerun Failed',
    'components.list.tasks.restartButtonDesc' => 'Rerun the selected failed tasks.',
    'components.list.tasks.restartLinkTitle' => 'Rerun',
    'components.list.tasks.restartLinkDesc' => 'Rerun this failed task.',
    'components.list.tasks.reBalanceLinkTitle' => 'Rebalance',
    'components.list.tasks.reBalanceLinkDesc' => 'Rebalance the service node for subscription creation and rerun this task.',
    'components.list.tasks.confirmOnRestart' => 'Do you want to rerun the selected failed tasks?',
    'components.list.tasks.hint.trigger' => '(?)',

    'components.list.subscriptions.nameColumn' => 'Subscription',
    'components.list.subscriptions.otherDomainsColumn' => 'Other Domains on the Subscription',
    'components.list.subscriptions.statusColumn' => 'Status',
    'components.list.subscriptions.slaveNodeColumn' => 'Service Node',
    'components.list.subscriptions.row.warning.notProvisioned' => 'The subscription is not yet available because provisioning is not finished.',
    'components.list.subscriptions.row.warning.node.maintenance' => 'The service node is under maintenance.',
    'components.list.subscriptions.row.warning.plesk-std-suspended' => 'The subscription is suspended: All services provided with the subscription are frozen and not accessible to Internet users.',
    'components.list.subscriptions.row.warning.plesk-std-expired' => 'The subscription is suspended because it is expired: All services provided with the subscription are frozen and not accessible to Internet users.',
    'components.list.subscriptions.row.warning.plesk-std-locked' => 'The subscription is locked for synchronization: It is excluded from syncing with the service plan because the subscription parameters were customized.',
    'components.list.subscriptions.row.warning.plesk-std-unsynchronized' => 'The subscription is unsynced with service plan: There are some services or resources that the plan offers but the subscription does not provide.',

    'components.list.subscriptions-ext.customizeUrlTitle' => 'Customize',
    'components.list.subscriptions-ext.resellerDescriptionTitle' => 'Reseller',
    'components.list.subscriptions-ext.ownerDescriptionTitle' => 'Customer',
    'components.list.subscriptions-ext.unlockLink.title' => 'Unlock & sync',
    'components.list.subscriptions-ext.unlockLink.hint' => 'Unlock the subscription and sync it with the plan.',
    'components.list.subscriptions-ext.subscriptionStatus.detailsPopup.trigger.title' => '(?)',
    'components.list.subscriptions-ext.subscriptionStatus.detailsPopup.title' => 'Status Details',
    'components.list.subscriptions-ext.subscriptionStatus.detailsPopup.wait' => 'Please wait...',
    'components.list.subscriptions-ext.subscriptionStatus.detailsPopup.listHeader' => 'The subscription status details:',
    'components.list.subscriptions-ext.subscriptionStatus' => [
        'undefined' => [
            'title' => 'Undefined',
            'hint' => 'Unable to retrieve the status',
            'detailsPopup' => [
                'pleskStdStatus' => 'Subscription status: Undefined',
                'provisionStatus' => 'Provisioning status: Undefined',
                'nodeStatus' => 'Node status: Undefined',
            ],
        ],
        'provision-done' => [
            'detailsPopup' => [
                'provisionStatus' => 'Provisioning status: Done',
            ],
        ],
        'provision-in-progress' => [
            'title' => 'Provisioning In Progress',
            'hint' => 'The subscription is synchronized with the service node.',
            'detailsPopup' => [
                'provisionStatus' => 'Provisioning status: In Progress',
            ],
        ],
        'provision-failed' => [
            'title' => 'Provisioning Failed',
            'hint' => 'Issues occurred during the subscription\'s synchronization with the service node.',
            'detailsPopup' => [
                'provisionStatus' => 'Provisioning status: Failed',
            ],
        ],
        'node-active' => [
            'detailsPopup' => [
                'nodeStatus' => 'Node status: Active',
            ],
        ],
        'node-inactive' => [
            'detailsPopup' => [
                'nodeStatus' => 'Node status: Inactive',
            ],
        ],
        'node-maintenance' => [
            'title' => 'Node On Maintenance',
            'hint' => 'Node is in maintenance mode.',
            'detailsPopup' => [
                'nodeStatus' => 'Node status: On Maintenance',
            ],
        ],
        'plesk-std-ok' => [
            'title' => 'Active',
            'hint' => 'Subscription status is OK: the subscription is active and synced with the plan.',
            'detailsPopup' => [
                'pleskStdStatus' => 'Subscription status: Active',
            ],
        ],
        'plesk-std-suspended' => [
            'title' => 'Suspended',
            'hint' => 'The subscription is suspended: All services provided with the subscription are frozen and not accessible to Internet users.',
            'detailsPopup' => [
                'pleskStdStatus' => 'Subscription status: Suspended',
            ],
        ],
        'plesk-std-expired' => [
            'title' => 'Suspended',
            'hint' => 'The subscription is suspended because it is expired: All services provided with the subscription are frozen and not accessible to Internet users.',
            'detailsPopup' => [
                'pleskStdStatus' => 'Subscription status: Suspended',
            ],
        ],
        'plesk-std-locked' => [
            'title' => 'Locked',
            'hint' => 'The subscription is locked for synchronization: It is excluded from syncing with the service plan because the subscription parameters were customized.',
            'detailsPopup' => [
                'pleskStdStatus' => 'Subscription status: Locked',
            ],
        ],
        'plesk-std-unsynchronized' => [
            'title' => 'Unsynchronized',
            'hint' => 'The subscription is unsynced with the service plan: There are some services or resources that the plan offers but the subscription does not provide.',
            'detailsPopup' => [
                'pleskStdStatus' => 'Subscription status: Unsynchronized',
            ],
        ],
    ],

    'components.list.dns-slaves.addButtonTitle' => 'Add DNS Slave Server',
    'components.list.dns-slaves.addButtonDesc' => 'Create a record about the DNS slave server managed by Plesk Multi Server.',
    'components.list.dns-slaves.removeButtonTitle' => 'Remove DNS Slave Server',
    'components.list.dns-slaves.removeButtonDesc' => 'Remove the selected records.',
    'components.list.dns-slave.confirmOnDelete' => 'Do you want to remove the selected DNS slave nodes?',
    'components.list.dns-slaves.ipColumn' => 'IP',
    'components.list.dns-slaves.domainNameColumn' => 'Domain name',
    'components.list.dns-slaves.portColumn' => 'SSH port',

    // view form messages
    'components.form.node.ipAddress' => 'Node IP',
    'components.form.node.validate.ipAddressFound' => 'Service node is already registered.',
    'components.form.node.ipAddress.desc' => 'The IP will be used for Service Node API calls. It can be IPv4 or IPv6 address',
    'components.form.node.validate.masterIpAddressFound' =>
        'Management node already has the IP address \'%value%\' registered,' .
        ' which is used for the Service Node registration, please remove the IP address.',
    'components.form.node.validate.mappingIpAddressFound' => 'Service node with IP address \'%value%\' is already registered.',
    'components.form.node.login' => 'Login',
    'components.form.node.login.desc' => 'Is used to connect with Service node',
    'components.form.node.password' => 'Password',
    'components.form.node.description' => 'Description',
    'components.form.node.webSharedIp.label' => 'Shared IP for web hosting',
    'components.form.node.webSharedIp.description' => 'A shared IP for newly created subscriptions.',
    'components.form.node.pleskVersion' => 'Plesk version',
    'components.form.node.subscriptionsCount' => 'Subscriptions',
    'components.form.node.isVps' => 'Node will work in VPS mode',
    'components.form.node.isVpsReadOnly' => 'Node is working in VPS mode',
    'components.form.node.passwordDesc' => 'Plesk Multi Server does not store your passwords',
    'components.form.node.status' => 'Status',
    'components.form.node.statusActive' => 'Active',
    'components.form.node.statusActive.description' => 'The node is ready to work.',
    'components.form.node.statusDisabled' => 'Disabled',
    'components.form.node.statusDisabled.description' => 'The node is excluded from balancing, no new subscriptions are provisioned to the node.',
    'components.form.node.statusMaintenance' => 'Maintenance',
    'components.form.node.statusMaintenance.description' => 'The node is on maintenance (for upgrade or technical works).',
    'components.form.node.validate.couldNotResolveHost' => 'Failed to resolve the node host',
    'components.form.node.validate.couldNotConnect' => 'Failed to connect to the node',
    'components.form.node.validate.exception' => 'An error occurred while checking the node: %%errorMessage%%',
    'components.form.node.validate.version.differ.plesk_os' => 'The remote Plesk\'s operating system is %%remoteValue%%. It must be %%masterValue%%',
    'components.form.node.validate.version.differ.plesk_os_version' => 'The remote Plesk\'s operating system version is %%remoteValue%%. It must be %%masterValue%%',
    'components.form.node.validate.version.xml.protocol' => 'The XML protocol version on the remote Plesk is %%remoteValue%%. At least %%masterValue%% is required.',
    'components.form.node.validate.version.plesk.unknown.version' => 'Cannot determine compatibility for management node version %%mnVersion%%',
    'components.form.node.validate.version.plesk.incompatible.version' => 'Plesk on the service node (%%snVersion%%) is incompatible with the management node\'s Plesk version (%%mnVersion%%). Compatible versions are %%compatibleVersions%%.',
    'components.form.node.validate.components.required' => 'Remote Plesk must have these components installed: %%componentsList%%.',
    'components.form.node.validate.webConfigurationError' => 'Plesk on the service node has errors in web server configuration files. Please resolve this issue on the service node manually.',
    'components.form.node.validate.extensions.extra' => 'Remote Plesk has extra extensions installed: %%extensionsList%%.',
    'components.form.node.validate.notEmpty.subscriptions' => 'The service node must be empty, but it already has subscriptions.',
    'components.form.node.validate.notEmpty.customers' => 'The service node must be empty, but it already has customers.',

    'components.form.task.id' => 'Task ID',
    'components.form.task.status' => 'Status',
    'components.form.task.statusMessage' => 'Status message',
    'components.form.task.scheduledAtTime' => 'Task schedule time',
    'components.form.task.lastExecTime' => 'Task last execution time',
    'components.form.task.completeTime' => 'Completion time',
    'components.form.task.node' => 'Service node',
    'components.form.task.customer' => 'Customer',
    'components.form.task.subscription' => 'Subscription',
    'components.form.task.objectName' => 'Object',
    'components.form.task.parent' => 'Parent task',
    'components.form.task.log' => 'Log',
    'components.form.task.log.oldValues' => 'Old Values',
    'components.form.task.log.newValues' => 'New Values',
    'components.form.task.log.attempt' => 'Attempt: %%num%%',
    'components.form.task.log.noAttempts' => 'No run',

    'components.form.dns-slave.ipAddress' => 'IP address',
    'components.form.dns-slave.port' => 'SSH port',
    'components.form.dns-slave.validate.ipAddressFound' => 'A DNS slave node with same IP address was already registered.',
    'components.form.dns-slave.validate.domainNameFound' => 'A DNS slave node with same domain name was already registered.',
    'components.form.dns-slave.login' => 'User login to access the DNS server',
    'components.form.dns-slave.privateKey' => 'Server private key',
    'components.form.dns-slave.privateKey.description' => 'Private part of the key for accessing the DNS server.',
    'components.form.dns-slave.rndcKey' => 'RNDC key',
    'components.form.dns-slave.domainName' => 'Domain name',
    'components.form.dns-slave.config.howto' => 'Please make sure that the configuration file for the named service (depending on operating system) on the DNS slave node contains the following instructions.',
    'components.form.dns-slave.config.use.rndc-key' => 'Enter your RNDC key or use this automatically generated one for adding a DNS slave server to Plesk Multi Server. This key will be used as the RNDC key for DNS slave configuration on service nodes and on the DNS slave server.',
    'components.form.dns-slave.config.more.info.text' => '<a href="%%howtoLink%%">Read this article</a> for more information.',
    'components.form.dns-slave.connection.error' => 'Failed to validate SSH connection availability: %%reason%%',

    'components.form.settings.allowManualSelectServiceNode.label' => 'Allow manual selection of service nodes',
    'components.form.settings.navigateByHostname.label' => 'Use the hostname for navigation to the management node in UI',
    'components.form.settings.tasksRotationPeriod.label' => 'Store tasks\' details for',
    'components.form.settings.tasksRotationPeriod.suffix' => 'month(s)',
    'components.form.settings.tasksRotationPeriod.description' => 'Plesk removes information about earlier provisioning tasks.',
    'components.form.settings.centralized.dns.enabled' => 'Enable centralized DNS management',
    'components.form.settings.centralized.dns.auto.manage.dns.template' => 'Automatically update the DNS zone template',

    'components.subForm.serviceNodeSelector.legend.autoSelectNode' => 'IP address types',
    'components.subForm.serviceNodeSelector.legend.manualSelectNode' => 'Service node',
    'components.subForm.serviceNodeSelector.serviceNode.label' => 'Service node address',
    'components.subForm.serviceNodeSelector.serviceNode.item' => '%%hostname%% (%%websitesCount%% websites)',
    'components.subForm.serviceNodeSelector.noneServiceNodes.item' => 'Not available service nodes',
    'components.subForm.serviceNodeSelector.ipv4.label' => 'IPv4 address type',
    'components.subForm.serviceNodeSelector.ipv6.label' => 'IPv6 address type',
    'components.subForm.serviceNodeSelector.ips.label' => 'IP addresses type',
    'components.subForm.serviceNodeSelector.ipType.shared' => 'Shared',
    'components.subForm.serviceNodeSelector.ipType.exclusive' => 'Dedicated',
    'components.subForm.serviceNodeSelector.ipType.none' => 'None',
    'components.subForm.serviceNodeSelector.notAvailableNode.label' => 'Unavailable IP address',
    'components.subForm.serviceNodeSelector.noneBothIpTypes.error' => 'Please provide the IP address type.',
    'components.subForm.serviceNodeSelector.updateIps.error' => 'Unable to balance IP addresses. Reason: %%reason%%',
    'components.subForm.serviceNodeSelector.notAvailableNode.error' => 'There are no service nodes ready for subscription provisioning.',

    'components.subForm.serviceNodeSharedIpAddresses.prefix.ipv4' => 'IPv4 ', // note space on the right
    'components.subForm.serviceNodeSharedIpAddresses.prefix.ipv6' => 'IPv6 ', // note space on the right

    'components.subForm.nodeHostname.nodeHostname.label' => 'Display name as',
    'components.subForm.nodeHostname.useIp.label' => 'Node IP: %%nodeIp%%',
    'components.subForm.nodeHostname.useHostname.label' => 'Node hostname: %%hostname%%',
    'components.subForm.nodeHostname.navigateByHostname.label' => 'Use the hostname for navigation to the node\'s UI',
    'components.subForm.nodeHostname.navigateByHostname.description' =>
        'The hostname will be used in the node\'s URL instead of an IP address. ' .
        'The hostname should have a valid SSL certificate and must resolve to a publicly available IP address.',

    'components.buttons.yes' => 'Yes',
    'components.buttons.no' => 'No',

    // custom buttons
    'components.customButtons.nodes' => 'Nodes',
    'components.customButtons.nodesDescription' => 'Manage service nodes.',
    'components.customButtons.tasks' => 'Tasks',
    'components.customButtons.tasksDescription' => 'Provisioning tasks.',
    'components.customButtons.dnsSlaves' => 'DNS slaves',
    'components.customButtons.dnsSlavesDescription' => 'Centralized management of DNS slave servers.',

    //Settings adjustment
    'component.global.settings.sync.warning' => 'The settings will be applied to all %%count%% nodes',
    'component.global.mailServer.settings.changed' => 'Mail Service settings changed, <a href="%%link%%">click here</a> to sync Mail Service settings with all active service nodes',
    'component.global.mailServer.settings.outgoingEmailMode.explicitIp.label' =>
        // See Plesk original 'mail__outgoing_email_mode_explicit_ip' translation
        'Send from the specified IP address (Note: Specify the IP address separately for each service node in its <a href="%%nodeListUrl%%">mail settings</a>).',
    'component.global.dnsTemplate.template.changed' => 'The DNS template was changed. <a href="%%link%%">Click here</a> to sync the DNS template with all active service nodes.',
    'component.global.settings.hostname.info' => 'All settings except the hostname will be synced across all nodes.',

    //License warnings
    'component.license.invalid.warning' => 'Your Plesk license has expired or is incompatible with Plesk Multi Server. Please <a href="/plesk/license">update license</a> or <a href="%%purchaseLink%%" target=_blank>click here</a> to purchase a new one.',

    // email notifications
    'components.emailNotifications.taskFailed.eventTitle' => 'The provisioning task has failed',
    'components.emailNotifications.pleskUpdatesAvailableForMasterNode.eventTitle' => 'Plesk updates are available for the management node',
    'components.emailNotifications.pleskUpdatesAvailableForServiceNodes.eventTitle' => 'Plesk updates are available for service nodes',
    'components.emailNotifications.pleskUpdatesAvailableForMasterAndServiceNodes.eventTitle' => 'Plesk updates are available for management and service nodes',
    'components.emailNotifications.serviceNodeBecameUnavailable.eventTitle' => 'Service node are unavailable',
    'components.emailNotifications.serviceNodeBecameAvailable.eventTitle' => 'Service node is available',
    'components.emailNotifications.serviceNodeBecameUnsupported.eventTitle' => 'Service node is unsupported',
    'components.emailNotifications.managementNodeLicenseExpired.eventTitle' => 'Management node license has expired',
    'components.emailNotifications.managementNodeLicenseUpdated.eventTitle' => 'Management node license was updated',
    'components.emailNotifications.conflictDomainNames.eventTitle' => 'Detected conflict of the domain names',
    'components.emailNotifications.nodeHasMinorIssues.eventTitle' => 'Detected minor issues on service node after back-sync',
    'components.emailNotifications.managementNodeLicenseUpdated.pmsLicenseValid' => 'The Plesk Multi Server license is valid',
    'components.emailNotifications.managementNodeLicenseUpdated.pmsLicenseInvalid' => 'The Plesk Multi Server license is invalid!',

    // UI notifications
    'components.uiNotifications.pleskUpdatesAvailableForMasterNode' =>
        'Plesk updates are available for the Multi Server <a href="%%masterNodeUpdateUrl%%">management node</a>.',
    'components.uiNotifications.pleskUpdatesAvailableForServiceNodes' =>
        'Plesk updates are available for %%serviceNodesCount%% Multi Server <a href="%%nodeListUrl%%">service nodes</a>.',
    'components.uiNotifications.pleskUpdatesAvailableForMasterAndServiceNodes' =>
        'Plesk updates are available for %%serviceNodesCount%% Multi Server <a href="%%nodeListUrl%%">service nodes</a>'
        . ' and the <a href="%%masterNodeUpdateUrl%%">management node</a>.'
        . '<br>We strongly recommend that you update the management node <b>after</b> service nodes.',

    'component.extensions.pleskMultiServer.changeStatusForbidden.error' =>
        'You cannot disable or enable the Plesk Multi Server extension.',
    'component.extensions.pleskMultiServer.removeForbidden.error' =>
        'Unable to remove the Plesk Multi Server extension because there are subscriptions or tasks related to Plesk Multi Server.' .
        ' Please delete all subscriptions, wait for the running tasks to complete, and try again.',
    'component.extensions.pleskMultiServer.removeDisabled.hint' =>
        'You can not remove the Plesk Multi Server extension because there are subscriptions or tasks related to Plesk Multi Server.',

    // API CLI
    'component.api.cli' => [
        'requiredOptions.error' => 'Required options are not specified: %%errorOptions%%',
        'noneOptions.error' => 'Should be specified at least one of options: %%options%%',
        'flagOptions.error' => 'For following options should be empty value: %%errorOptions%%',
        'noFlagOptions.error' => 'For following options should be non empty value: %%errorOptions%%',
        'nodeNotFound.error' => 'Specified node is not found',
        'commands.default' => [
            'unknownCommand.error' => 'Unknown command: %%command%%',
        ],
        'commands.help' => [
            'usage' => "Usage:\n" .
                "  plesk bin extension --call %%extension%% <command> [ <subcommand> [ <options> ... ] ]\n" .
                "  plesk ext %%extension%% <command> [ <subcommand> [ <options> ... ] ]",
            'availableCommandsHeader' => "Available commands:",
            'availableCommands' => [
                'node' => 'Service Nodes management.',
                'task' => 'Task management.',
                'balancer' => 'Custom Balancer management.',
                'help' => 'Displays this help page.',
            ],
            'note' => "Help:\n" .
                "  The help command displays help for a given command\n\n" .
                "  plesk ext %%extension%% --node --help",
        ],
        'commands.node' => [
            'commands.default' => [
                'unknownCommand.error' => 'Unknown subcommand: %%command%%',
            ],
            'commands.help' => [
                'arguments.error' => "Specified wrong options. Usage:\n" .
                    'plesk ext %%extension%% --node --help',
                'usage' => "Usage:" .
                    "\n  plesk bin extension --call %%extension%% --node <subcommand> [ <options> ... ]" .
                    "\n  plesk ext %%extension%% --node <subcommand> [ <options> ... ]",
                'availableCommandsHeader' => "Available subcommands:",
                'availableCommands' => [
                    'list' => 'Get a list of all service nodes currently connected.',
                    'add' => 'Connect a new service node.',
                    'remove' => 'Delete connected service node.',
                    'set' => 'Set additional parameters a service node.',
                    'reissue-secret-key' => 'Issue a new secret key for a service node.',
                    'status' => 'Get status for a service node.',
                    'info' => 'Get details for a service node.',
                    'ip-list' => 'Get a list of IP addresses for a service node.',
                    'help' => 'Displays this help page.',
                ],
                'availableOptionsHeader' => "Available options:",
                'availableOptions' => [
                    'id' => 'Service node identifier.',
                    'ip' => 'Service node IP address.',
                    'hostname' => 'Service node hostname.',
                    'passwd' => 'Admin password.',
                    'description' => 'Service node description.',
                    'navigate-by-hostname' => 'Set this option for use the hostname in the node\'s URL instead of an ' .
                        'IP address. The hostname should have a valid SSL certificate and must resolve to a publicly ' .
                        'available IP address.',
                    'status' => 'Service node status.',
                    'web-shared-ipv4' => 'Web hosting IPv4 Address.',
                    'web-shared-ipv6' => 'Web hosting IPv6 Address.',
                    'free' => 'Only free IP addresses.',
                    'hide-header' => 'Do not output column names a table.',
                ],
            ],
            'commands.list' => [
                'arguments.error' => "Specified wrong options. Usage:\n" .
                    'plesk ext %%extension%% --node --list [-hide-header]',
                'columns' => [
                    'id' => 'ID',
                    'ipAddress' => 'IP',
                    'hostname' => 'Hostname',
                    'status' => 'Status',
                ],
            ],
            'commands.add' => [
                'arguments.error' => "Specified wrong options. Usage:\n" .
                    'plesk ext %%extension%% --node --add -ip <node_ip> -passwd <admin_password> ' .
                    '[-description <\'description_text\'>] [-navigate-by-hostname] ' .
                    '[-status <active | disabled | maintenance>] [-web-shared-ipv4 <ipv4>] [-web-shared-ipv6 <ipv6>]',
                'success' => 'Service node with IP %%ipAddress%% was successfully registered.',
                'taskScheduled' => 'Task for service node synchronization was successfully added. ' .
                    'Execute command \'plesk ext %%extension%% --task --status -id %%taskId%%\' for checking ' .
                    'task status of synchronization the service node.',
                'waitingTaskScheduled' => 'Task (ID: %%taskId%%) for synchronize service node was started. ' .
                    'Please wait until task is complete...',
                'taskSuccessfullyFinished' => 'Task for synchronize service node was successfully completed.',
                'taskFinishedWithError' => 'Task for synchronize service node was completed with error. %%errorMessage%%',
            ],
            'commands.remove' => [
                'arguments.error' => "Specified wrong options. Usage:\n" .
                    'plesk ext %%extension%% --node --remove -id <node_id> | -ip <node_ip> | ' .
                    '-hostname <node_hostname>',
                'success' => 'Service node with IP %%ipAddress%% was marked to delete.',
                'taskScheduled' => 'Task for delete service node was successfully added. ' .
                    'Execute command \'plesk ext %%extension%% --task --status -id %%taskId%%\' for checking ' .
                    'task status of deletion the service node.',
                'waitingTaskScheduled' => 'Task (ID: %%taskId%%) for delete service node was started. ' .
                    'Please wait until task is complete...',
                'taskSuccessfullyFinished' => 'Task for delete service node was successfully completed.',
                'taskFinishedWithError' => 'Task for delete service node was completed with error. %%errorMessage%%',
            ],
            'commands.set' => [
                'arguments.error' => "Specified wrong options. Usage:\n" .
                    'plesk ext %%extension%% --node --set -id <node_id> | -ip <node_ip> | ' .
                    '-hostname <node_hostname> -status <active | disabled | maintenance>',
                'success' => 'Status for service node with IP %%ipAddress%% was successfully changed.',
                'taskScheduled' => 'Task for service node synchronization was successfully added. ' .
                    'Execute command \'plesk ext %%extension%% --task --status -id %%taskId%%\' for checking ' .
                    'task status of synchronization the service node.',
                'waitingTaskScheduled' => 'Task (ID: %%taskId%%) for synchronize service node was started. ' .
                    'Please wait until task is complete...',
                'taskSuccessfullyFinished' => 'Task for synchronize service node was successfully completed.',
                'taskFinishedWithError' => 'Task for synchronize service node was completed with error. %%errorMessage%%',
            ],
            'commands.reissue-secret-key' => [
                'arguments.error' => "Specified wrong options. Usage:\n" .
                    'plesk ext %%extension%% --node --reissue-secret-key -id <node_id> | -ip <node_ip> | ' .
                    '-hostname <node_hostname> -passwd <admin_password>',
                'success' => 'Secret key for service node with IP %%ipAddress%% was successfully recreated.',
                'taskScheduled' => 'Task for service node synchronization was successfully added. ' .
                    'Execute command \'plesk ext %%extension%% --task --status -id %%taskId%%\' for checking ' .
                    'task status of synchronization the service node.',
                'waitingTaskScheduled' => 'Task (ID: %%taskId%%) for synchronize service node was started. ' .
                    'Please wait until task is complete...',
                'taskSuccessfullyFinished' => 'Task for synchronize service node was successfully completed.',
                'taskFinishedWithError' => 'Task for synchronize service node was completed with error. %%errorMessage%%',
            ],
            'commands.status' => [
                'arguments.error' => "Specified wrong options. Usage:\n" .
                    'plesk ext %%extension%% --node --status -id <node_id> | -ip <node_ip> | ' .
                    '-hostname <node_hostname>',
            ],
            'commands.info' => [
                'arguments.error' => "Specified wrong options. Usage:\n" .
                    'plesk ext %%extension%% --node --info  -id <node_id> | -ip <node_ip> | ' .
                    '-hostname <node_hostname>',
                'fields' => [
                    'id' => 'ID: %%id%%',
                    'ipAddress' => 'IP: %%ipAddress%%',
                    'webSharedIpv4' => 'Shared IPv4 for web hosting: %%webSharedIpv4%%',
                    'webSharedIpv6' => 'Shared IPv6 for web hosting: %%webSharedIpv6%%',
                    'hostname' => 'Hostname: %%hostname%%',
                    'displayName' => 'Display name as: %%displayName%%',
                    'status' => 'Status: %%status%%',
                    'pleskVersion' => 'Plesk version: %%pleskVersion%%',
                    'description' => "Description:\n%%description%%",
                ],
            ],
            'commands.ip-list' => [
                'arguments.error' => "Specified wrong options. Usage:\n" .
                    'plesk ext %%extension%% --node --ip-list  -id <node_id> | -ip <node_ip> | ' .
                    '-hostname <node_hostname> [-free] [-hide-header]',
                'columns' => [
                    'ipAddress' => 'IP',
                    'version' => 'Protocol',
                    'type' => 'Type',

                ],
            ],
        ],
        'commands.task' => [
            'commands.default' => [
                'unknownCommand.error' => 'Unknown subcommand: %%command%%',
            ],
            'commands.help' => [
                'arguments.error' => "Specified wrong options. Usage:\n" .
                    'plesk ext %%extension%% --task --help',
                'usage' => "Usage:" .
                    "\n  plesk bin extension --call %%extension%% --task <subcommand> [ <options> ... ]" .
                    "\n  plesk ext %%extension%% --task <subcommand> [ <options> ... ]",
                'availableCommandsHeader' => "Available subcommands:",
                'availableCommands' => [
                    'list' => 'Get a list of tasks.',
                    'get-last-id' => 'Get a identifier for a last task.',
                    'status' => 'Get a status for a specified task.',
                    'help' => 'Displays this help page.',
                ],
                'availableOptionsHeader' => "Available options:",
                'availableOptions' => [
                    'id' => 'Task identifier.',
                    'status' => 'Task status.',
                    'customer-id' => 'Customer identifier.',
                    'subscription-id' => 'Subscription identifier.',
                    'service-plan-id' => 'Service plan identifier.',
                    'node-id' => 'Service node identifier.',
                    'hide-header' => 'Do not output column names a table.',
                ],
            ],
            'commands.list' => [
                'arguments.error' => "Specified wrong options. Usage:\n" .
                    'plesk ext %%extension%% --task --list [-id <task_id>] [-status <\'new\' | \'queue\' | ' .
                    '\'running\' | \'done\' | \'error\' | \'prepare queue\' | \'prepare running\' | \'waiting\' | ' .
                    '\'blocked\'>] [-customer-id <customer_id>] [-subscription-id <subscription_id>] ' .
                    '[-service-plan-id <service_plan_id>] [-node-id <node_id>] [-hide-header]',
                'columns' => [
                    'id' => 'ID',
                    'action' => 'Action',
                    'parentId' => 'Parent ID',
                    'objectName' => 'Object',
                    'status' => 'Status',
                    'nodeId' => 'Node ID',
                    'customerId' => 'Customer ID',
                    'subscriptionId' => 'Subscription ID',
                    'servicePlanId' => 'Service plan ID',
                ],
            ],
            'commands.get-last-id' => [
                'arguments.error' => "Specified wrong options. Usage:\n" .
                    'plesk ext %%extension%% --task --get-last-id',
            ],
            'commands.status' => [
                'arguments.error' => "Specified wrong options. Usage:\n" .
                    'plesk ext %%extension%% --task --status -id <task_id>',
            ],
            'commands.wait-task-complete' => [
                'waitingTaskScheduled' => 'Please wait until task %%taskId%% is completed...',
                'taskSuccessfullyFinished' => 'Task was successfully completed.',
                'taskFinishedWithError' => 'Task was completed with error. %%errorMessage%%',
            ],
        ],
        'commands.balancer' => [
            'commands.default' => [
                'unknownCommand.error' => 'Unknown subcommand: %%command%%',
            ],
            'commands.help' => [
                'arguments.error' => "Specified wrong options. Usage:\n" .
                    'plesk ext %%extension%% --balancer --help',
                'usage' => "Usage:" .
                    "\n  plesk bin extension --call %%extension%% --balancer <subcommand> [ <options> ... ]" .
                    "\n  plesk ext %%extension%% --balancer <subcommand> [ <options> ... ]",
                'availableCommandsHeader' => "Available subcommands:",
                'availableCommands' => [
                    'register' => 'Register the custom balancer.',
                    'reset' => 'Reset the custom balancer.',
                    'help' => 'Displays this help page.',
                ],
                'availableOptionsHeader' => "Available options:",
                'availableOptions' => [
                    'class' => 'Name of custom balancer class (use with the \'register\' command).',
                ],
            ],
            'commands.register' => [
                'arguments.error' => "Specified wrong options. Usage:\n" .
                    'plesk ext %%extension%% --balancer --register -class <\'class\'>',
                'option.class' => [
                    'notFound.error' => 'Class \'%%class%%\' not found',
                    'wrongInterface.error' => 'Class \'%%class%%\' should implement interface \'%%balancerInterface%%\'',
                ],
                'success' => 'Custom class for balancing of service nodes was successfully registered.',
            ],
            'commands.reset' => [
                'arguments.error' => "Specified wrong options. Usage:\n" .
                    'plesk ext %%extension%% --balancer --reset',
                'success' => 'Class for balancing of service nodes was successfully reset to default.',
            ],
        ],
    ],

    'component.api.cli.forwarded.utility' => [
        'requiredArguments.error' => 'Following arguments should be specified: %%arguments%%',
        'atLeastOneOfArguments.error' => 'At least one of following arguments should be specified: %%arguments%%',
        'retrieveNode.error' => 'Unable to retrieve node. %%errorMessage%%',
        'retrieveSpecifiedNode.error' => 'Specified node is not found',
        'disabled.error' => 'Command \'%%command%%\' is denied on management node.',
        'subscription' => [
            'retrieveNodeByIp.error' => 'Unable to retrieve node with requested IP addresses. %%errorMessage%%',
            'ipType.error' => "Argument '%%argument%%' should have at one of values: %%allowedIpTypes%%.",
            'disabledArguments.error' =>
                'Operations with domain, subdomain, domain alias via subscription command is denied on management ' .
                'node. You may used site/subdomain/domalias command instead subscription command.',
            'additionalOption' => [
                'ipv4' => 'IPv4 address type',
                'ipv6' => 'IPv6 address type',
                'nodeId' => 'Service node ID',
                'nodeIp' => 'Service node IP',
                'nodeHostname' => 'Service node hostname',
            ],
            'create' => [
                'subscriptionNotFound' => 'Subscription \'%%subscriptionName%%\' not found on management node.',
                'taskNotFound' => 'Task for provision subscription \'%%subscriptionName%%\' not found.',
                'taskError' => 'Subscription creation task was completed with error. %%errorMessage%%',
            ],
            'remove' => [
                'subscriptionNotFound' => 'Subscription \'%%subscriptionName%%\' not found on management node.',
                'taskNotFound' => 'Task for delete subscription \'%%subscriptionName%%\' not found.',
                'taskError' => 'Subscription deletion task was completed with error. %%errorMessage%%',
            ],
            'info' => [
                'additionalSectionTitle' => 'Plesk Multi Server',
                'additionalRows' => [
                    'status' => 'Status:',
                    'nodeId' => 'Service node ID:',
                    'nodeIp' => 'Service node IP address:',
                    'nodeHostname' => 'Service node hostname:',
                ],
                'mapping.error' => 'Subscription not found in mapping.',
                'retrieve.error' =>
                    'Unable to retrieve subscription information from Plesk Multi Server. Reason: %%message%%',
            ],
        ],
    ],

    // common
    '__perm_denied' => 'Permission denied.',
    '__task.status.any' => 'Any',
    '__task.status.blocked' => 'Blocked',
    '__task.status.new' => 'New',
    '__task.status.queue' => 'Queued',
    '__task.status.progress' => 'Running',
    '__task.status.waiting' => 'Waiting',
    '__task.status.done' => 'Finished',
    '__task.status.error' => 'Failed',

    '__task.action.admin_update' => 'Administrator account update',
    '__task.action.auto_manage' => 'DNS zone template preparation',
    '__task.action.client_create' => 'Customer creation',
    '__task.action.client_update' => 'Customer update',
    '__task.action.client_status_update' => 'Customer status update',
    '__task.action.client_delete' => 'Customer deletion',
    '__task.action.template_admin_create' => 'Service plan creation',
    '__task.action.template_admin_update' => 'Service plan update',
    '__task.action.template_admin_delete' => 'Service plan deletion',
    '__task.action.domain_create' => 'Subscription creation',
    '__task.action.domain_update' => 'Subscription update',
    '__task.action.domain_plan_change' => 'Subscription\'s service plan update',
    '__task.action.domain_status_update' => 'Subscription status update',
    '__task.action.domain_limits_update' => 'Subscription limits update',
    '__task.action.domain_delete' => 'Subscription deletion',
    '__task.action.domain_alias_create' => 'Domain alias creation',
    '__task.action.domain_alias_update' => 'Domain alias update',
    '__task.action.domain_alias_delete' => 'Domain alias deletion',
    '__task.action.install-extension' => 'Install service node extension',
    '__task.action.install-dns-slave-extension' => 'Install DNS slave management extension',
    '__task.action.site_create' => 'Site creation',
    '__task.action.site_delete' => 'Site deletion',
    '__task.action.site_update' => 'Site update',
    '__task.action.site_status_update' => 'Site status update',
    '__task.action.sync_locales' => 'Locales sync',
    '__task.action.sync_notifications_settings' => 'Notifications settings sync',
    '__task.action.sync_database_settings' => 'Database settings sync',
    '__task.action.sync_update_settings' => 'Plesk updates settings sync',
    '__task.action.sync_server_settings' => 'Server settings sync',
    '__task.action.sync_security_policy' => 'Security policy sync',
    '__task.action.sync_session_settings' => 'Session settings sync',
    '__task.action.terminate_expired_plesk_sessions' => 'Expired Plesk sessions termination',
    '__task.action.sync_version_info' => 'Version information sync',
    '__task.action.sync_branding_settings' => 'Branding settings sync',
    '__task.action.sync_php_handlers' => 'PHP handlers sync',
    '__task.action.sync_skin' => 'UI skin sync',
    '__task.action.validate' => 'Node compatibility validation',
    '__task.action.subdomain_create' => 'Subdomain creation',
    '__task.action.subdomain_settings_update' => 'Subdomain settings update',
    '__task.action.subdomain_update' => 'Subdomain update',
    '__task.action.subdomain_delete' => 'Subdomain deletion',
    '__task.action.database_server_create' => 'Database server creation',
    '__task.action.database_server_update' => 'Database server update',
    '__task.action.database_server_delete' => 'Database server deletion',
    '__task.action.sync' => 'Service node sync',
    '__task.action.deploy' => 'Service node deployment',
    '__task.action.delete' => 'Service node deletion',
    '__task.action.ip_address_create' => 'IP address creation',
    '__task.action.ip_address_update' => 'IP address update',
    '__task.action.ip_address_delete' => 'IP address deletion',
    '__task.action.domain_usage_size_update' => 'Subscription statistics update',
    '__task.action.domain_usage_traffic_update' => 'Subscription traffic usage update',
    '__task.action.phosting_update' => 'Physical hosting update',
    '__task.action.admin_alias_create' => 'Administrator alias creation',
    '__task.action.admin_alias_update' => 'Administrator alias update',
    '__task.action.admin_alias_delete' => 'Administrator alias deletion',
    '__task.action.license_update' => 'License update',
    '__task.action.license_expired' => 'License expiration',
    '__task.action.sync_domains_restriction' => 'Prohibited domains sync',
    '__task.action.sync_dns_zone_template' => 'DNS zone template sync',
    '__task.action.sync_zones_with_dns_template' => 'Sync of DNS zones with DNS template',
    '__task.action.sync_dns_zone_template_soa_record' => 'Sync of DNS zone template\'s SOA record',
    '__task.action.sync_local_dns_status' => 'Sync of local DNS service state',
    '__task.action.sync_mail_server_settings' => 'Mail server settings sync',
    '__task.action.sync_web_mail_services' => 'Webmail services sync',
    '__task.action.extension_install' => 'Extension installation',
    '__task.action.extension_uninstall' => 'Extension uninstalling',
    '__task.action.extension_upgrade' => 'Extension upgrade',
    '__task.action.extension_status_update' => 'Extension status update',
    '__task.action.update_slave_node_config' => 'Service nodes config update',

    '__task.message.disabled.node' => 'The service node is disabled. Enable the node before provision.',
    '__task.message.inactive.node' => 'The service node is unavailable. Make sure that there are no issues, and  re-check the node (Nodes > Re-check).',

    '__node.status.active' => 'Active',
    '__node.status.active.description' => 'The node is active, has no issues, and takes part in balancing.',
    '__node.status.activating' => 'Being activated',
    '__node.status.activating.description' => 'Plesk Multi Server is performing operations on the node. The node does not take part in balancing, the node status will be changed soon.',
    '__node.status.disabled' => 'Disabled',
    '__node.status.disabled.description' => 'The node was deactivated. It does not take part in balancing, but all necessary settings will be synced with this node.',
    '__node.status.disabling' => 'Being deleted',
    '__node.status.disabling.description' => 'The node will be deleted soon.',
    '__node.status.maintenance' => 'Maintenance',
    '__node.status.maintenance.description' => 'The administrator set the node\'s status to maintenance. The node does not take part in balancing and is not available for customers.',
    '__node.status.unsupported' => 'Unsupported',
    '__node.status.unsupported.description' => 'The node is incompatible with Plesk Multi Server.',
    '__node.status.unavailable' => 'Unavailable',
    '__node.status.unavailable.description' => 'The service node cannot connect to the management node, or an unexpected error occurred.',
    '__node.status.unknown' => 'Failed to obtain the status',
    '__node.pleskVersion.justVersion' => '%%version%%',
    '__node.pleskVersion.patchInstalled' => '%%version%% MU#%%installedPatch%%',
    '__node.pleskVersion.updateAvailable' => '%%version%% Update to MU#%%availablePatch%% is available',
    '__node.pleskVersion.patchInstalledAndUpdateAvailable' => '%%version%% MU#%%installedPatch%% Update to MU#%%availablePatch%% is available',
    '__node.pleskVersion.iconTitle.upToDate' => 'The Plesk server is up-to-date',
    '__node.pleskVersion.iconTitle.updateAvailable' => 'Plesk updates are available',
];
