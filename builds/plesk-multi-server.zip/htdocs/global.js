// Copyright 1999-2017. Parallels IP Holdings GmbH. All Rights Reserved.
(function() { // Anonymous namespace

Jsw.namespace('PleskExt.PleskMultiServer');

function removeElementByClass(elementClass, upTo) {
    var element = $$('.' + elementClass).first();
    if (element && upTo) {
        element = element.up(upTo);
    }
    if (element) {
        element.remove();
    }
}

function replacePopups(replacePrefix, title, waitMsg, url) {
    $$('span.hint.hint-info').each(function (hintElement) {
        if (0 != hintElement.id.indexOf(replacePrefix)) {
            return;
        }
        new Jsw.DynamicPopupHint.Instance({
            title: title,
            waitMsg: waitMsg,
            url: url + hintElement.id.replace(replacePrefix + '-', ''),
            placement: 'right',
            target: hintElement.id
        });
    });
}

function changeOnRedraw(listId, callable) {
    var list = Jsw.getComponent(listId);
    if (!list) {
        return;
    }
    var prevOnRedrawFunc = list._onRedraw;
    list._onRedraw = function () {
        prevOnRedrawFunc();
        callable();
    };
    list._onRedraw();
}

PleskExt.PleskMultiServer.hideViewSwitcher = function () {
    removeElementByClass('view-switcher');
};

PleskExt.PleskMultiServer.hideCustomerInterface = function () {
    $$('body').first().toggleClassName('page-sidebar-closed');
    removeElementByClass('top-webspace');
    removeElementByClass('icon-profile', 'li');
    var pathbar = Jsw.getComponent('pathbar');
    if (pathbar) {
        pathbar.hide();
    }
};

PleskExt.PleskMultiServer.removeAccountMenu = function () {
    var accountMenu = Jsw.getComponent("account-menu");
    if (accountMenu) {
        $('account-menu').replace('<span>' + accountMenu._getConfigParam('title') + '</span>');
    }
};

function sendActionRequest(url, action, objectType, objectId) {
    return new Ajax.Request(Jsw.prepareUrl(url), {
        method: 'post',
        parameters: {
            syncObjectType: objectType ? objectType : null,
            syncAction: action,
            syncObjectId: objectId ? objectId : null
        }
    });
}

PleskExt.PleskMultiServer.wrapButtonClick = function (buttonsIds, url, action) {
    buttonsIds = [].concat(buttonsIds);

    buttonsIds.forEach(function(buttonId) {
        var button = Jsw.getComponent(buttonId);
        if (button) {
            button.addEventObserver('click', function(event) {
                sendActionRequest(url, action);
            });
        }
    });
};

PleskExt.PleskMultiServer.wrapButtonClickLegacy = function (buttonsIds, url, action) {
    buttonsIds = [].concat(buttonsIds);

    buttonsIds.forEach(function(buttonId) {
        var button = $(buttonId);
        if (button) {
            button.addEventListener('click', function(event) {
                sendActionRequest(url, action, buttonId);
            });
        }
    });
};

PleskExt.PleskMultiServer.signUp = function (formId, url, action, objectType, objectId) {
    var form = Jsw.getComponent('adminpanel-form-final-' + formId);
    if (!form) {
        return;
    }
    form._processForm = form._processForm.wrap(function (callOriginal, response) {
        callOriginal(response);
        if (response.redirect && 'success' == response.status) {
            sendActionRequest(url, action, objectType, objectId);
        }
    });
};


PleskExt.PleskMultiServer.signUpToLegacy = function (url, action) {
    if (!lsubmit) {
        return;
    }

    lsubmit = lsubmit.wrap(function (callOriginal, f) {
        if (callOriginal(f)) {
            sendActionRequest(url, action);
        }
    });

    $(document).observe('click', function(event) {
        var element = event.findElement('a[data-method="post"]');
        if (element) {
            event.preventDefault();
            sendActionRequest(url, action);
        }
    });
};


PleskExt.PleskMultiServer.signUpToList = function (listId, url, action) {
    var list = Jsw.getComponent(listId + '-list');
    if (!list) {
        return;
    }

    list.execGroupOperation = list.execGroupOperation.wrap(function (callOriginal, params) {
        if (params.onSuccess) {
            params.onSuccess = params.onSuccess.wrap(function (callOriginal) {
                callOriginal();
                sendActionRequest(url, action);
            })
        } else {
            params.onSuccess = function() {
                sendActionRequest(url, action);
            };
        }

        callOriginal(params);
    });

    $(document).observe('click', function (event) {
        var element = event.findElement('a[data-action-name]');
        if (element) {
            sendActionRequest(url, action);
            return;
        }
        var element = event.findElement('a[data-method="post"]');
        if (element) {
            sendActionRequest(url, action);
        }
    });
};

PleskExt.PleskMultiServer.replaceResourcesUsagePopup = function(listComponentId, title, waitMsg, url) {
    changeOnRedraw(listComponentId, function () {
        replacePopups('hint-item', title, waitMsg, url);
        var resourceUsageSelects = document.getElementsByName('searchFilter[resourceUsage][searchText]');
        if (resourceUsageSelects) {
            $A(resourceUsageSelects).forEach(function(resourceUsageSelect) {
                resourceUsageSelect.parentElement.hide();
            });
        }
    });
};

PleskExt.PleskMultiServer.replaceSubscriptionStatusPopup = function(listComponentId, title, waitMsg, url) {
    changeOnRedraw(listComponentId, function () {
        replacePopups('subscription-id', title, waitMsg, url);
    });
};

PleskExt.PleskMultiServer.addStatusMessage = function (status, message, renderToElement) {
    if (!renderToElement) {
        renderToElement = $$('.heading')[0].up();
    }

    Jsw.addStatusMessage(status, message, {renderTo: renderToElement});
};

PleskExt.PleskMultiServer.subscriptionColumnRenderer = function (item, isDisabled) {
    if (0 == item.id) {
        return '<a href="' + Jsw.baseUrl + item.link + '">' + item.name.escapeHTML() + '</a>';
    }

    var subscriptionName = item.domainDisplayName.escapeHTML() + ' (' + item.planName.escapeHTML() + ')';
    var subscriptionLink = item.overviewUrl
        ? '<a href="' + Jsw.prepareUrl(item.overviewUrl) + '">' + subscriptionName + '</a>'
        : subscriptionName;

    var hintId = 'hint-item-' + item.id;
    var description = '';
    if (item.adminDescription) {
        description += '<div class="hint">' + item.adminDescription.truncate(50, '...').escapeHTML() +
            '<span class="tooltipData">' + item.adminDescription.escapeHTML() + '</span></div>';
    }
    if (item.resellerDescription) {
        var descriptionTitle = (item.hideResellerTitleDescription) ? '' : item.resellerDescriptionTitle;
        description += '<div class="hint">' + descriptionTitle +
            item.resellerDescription.truncate(50, '...').escapeHTML() + '<span class="tooltipData">' +
            item.resellerDescription.escapeHTML() +
            '</span></div>';
    }
    if (item.ownerDescription) {
        description += '<div class="hint">' + item.ownerDescriptionTitle + ': ' +
            item.ownerDescription.truncate(50, '...').escapeHTML() + '<span class="tooltipData">' +
            item.ownerDescription.escapeHTML() + '</span></div>';
    }

    return subscriptionLink + '&nbsp;<span class="hint hint-info" id="' + hintId + '">' + '(?)</span>' + description;
};

PleskExt.PleskMultiServer.subscriptionStatusColumnRenderer = function (item, isDisabled) {
    var status = item.extPleskMultiServerStatus;
    var popupTrigger = "<span class='hint hint-info' id='subscription-id-" + item.id + "'>" + status.hintTriggerTitle +
        "</span>";
    return "<img src='" + status.icon + "' title='" + status.title + "'/>&nbsp;" + status.description + "&nbsp;" +
        popupTrigger;
};

PleskExt.PleskMultiServer.removeTools = function (listComponentId, tools) {
    changeOnRedraw(listComponentId, function () {
        [].concat(tools).forEach(function(toolClass) {
            removeElementByClass(toolClass);
        });

        var toolbar = $$('.objects-toolbar').first();
        if (toolbar) {
            PleskExt.PleskMultiServer.cleanToolbarSeparators(toolbar);
        }
    });
};

PleskExt.PleskMultiServer.cleanToolbarSeparators = function (toolbar) {
    // remove separator if first
    var first = toolbar.firstDescendant();
    if (first && first.hasClassName('separator')) {
        first.remove();
    }
    // remove double separator
    toolbar.select('.separator').each(function(separator) {
        if (separator.next().hasClassName('separator')) {
            separator.remove();
        }
    });
};

PleskExt.PleskMultiServer.subscriptionCustomizeColumnRenderer = function (item, isDisabled) {
    if (!item.extPleskMultiServerCustomizeData) {
        return '';
    }
    var data = item.extPleskMultiServerCustomizeData;
    var actionName = data.title.escapeHTML();
    var customize = ('' == data.url)
        ? actionName
        : '<a href="' + Jsw.prepareUrl(data.url) + '">' + actionName + '</a>';
    return "<img src='" + data.icon + "' title='" + actionName + "'/>&nbsp;" + customize;
};

PleskExt.PleskMultiServer.subscriptionUnlockColumnRenderer = function (item, isDisabled) {
    if (!item.extPleskMultiServerUnlockData) {
        return '';
    }
    var data = item.extPleskMultiServerUnlockData;
    var unlock = ('' == data.url)
        ? data.title.escapeHTML()
        : '<a href="javascript:;" onclick="Jsw.redirectPost(\'' + Jsw.prepareUrl(data.url) + '\');">' +
    data.title.escapeHTML() + '</a>';
    return "<img src='" + data.icon + "' title='" + data.hint.escapeHTML() + "'/>&nbsp;" + unlock;
};

/**
 * Select DOM element by given selector.
 *
 * @param selector string|{'selector': "css-selector", 'upTo': "parent-element-selector"}
 * @returns Element|undefined
 */
function selectElement(selector) {
    if (typeof selector === 'string') {
        selector = {'selector': selector};
    }
    var element = $$(selector['selector']).first();
    if (!element) {
        return;
    }

    var upTo = selector['upTo'];
    if (upTo) {
        element = element.up(upTo)
    }

    return element;
}

/**
 * Remove DOM emlements by given selectors.
 *
 * @param selectors []
 *
 * @see selectElement
 */
PleskExt.PleskMultiServer.removeElementsBySelector = function (selectors) {
    selectors.forEach(function(selector) {
        var element = selectElement(selector);
        if (element) {
            element.remove();
        }
    });
};

/**
 * Replace DOM element content.
 *
 * @param selector string|
 * @param content string|Element
 *
 * @see selectElement
 */
PleskExt.PleskMultiServer.updateElement = function (selector, content) {
    var element = selectElement(selector);
    if (element) {
        element.update(content);
    }
};

PleskExt.PleskMultiServer.phpHandlerColumnRenderer = function (item, isDisabled) {
    if (item.syncTaskId) {
        return '<span>' + item.name.escapeHTML() + '</span>' +
            '<div id="handler-sync-status-' + item.id + '" class="hint-sub hint-wait">' + item.syncMessage + '</div>';
    }
    if (!item.registered) {
        return item.name.escapeHTML();
    }
    return '<a href="' + Jsw.prepareUrl(item.urlPrefix + '/' + item.id) + '">' + item.name.escapeHTML() + '</a>';
};

PleskExt.PleskMultiServer.replaceOnclickLegacy = function (replaceConfig) {
    replaceConfig.forEach(function (cfg) {
        var handler = cfg['handler'];
        var items = $$(cfg['selector']);
        if (items) {
            items.forEach(function(item) {
                item['onclick'] = Function(handler);
            });
        }
    });
};

PleskExt.PleskMultiServer.redirectTo = function (url) {
    go_to(url);
};

PleskExt.PleskMultiServer.replaceHandlerColumnSelectionIsDisabled = function (params) {
    var list = Jsw.getComponent(params.listId);
    if (!list) {
        return;
    }

    var originalIsDisabledItem = list.isDisabledItem;
    list.isDisabledItem = function (item) {
        return originalIsDisabledItem(item) || item.extPleskMultiServerIsDisabled;
    };

    list.redraw = list.redraw.wrap(function (callOriginal, place, dataLen) {
        callOriginal(place, dataLen);
        var pmsCheckboxWrapper = $$('tr[data-row-id=' + params.extensionId + '] span.checkbox-disabled-wrapper').first();
        if (pmsCheckboxWrapper) {
            pmsCheckboxWrapper.title = params.isDisabledHint;
        }
    });
    list._initList = true;
    list.redraw();
};

})(); // END Anonymous namespace
