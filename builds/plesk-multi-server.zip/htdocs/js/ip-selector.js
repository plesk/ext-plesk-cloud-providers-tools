// Copyright 1999-2017. Parallels IP Holdings GmbH. All Rights Reserved.
(function() { // Anonymous namespace

Jsw.namespace('PleskExt.PleskMultiServer');

PleskExt.PleskMultiServer.replacePleskIpSelector = function (prefix, publicIps, isVpsMode) {
    isVpsMode = isVpsMode || false;
    var ipSelectRows = [];
    $A(['ipv4', 'ipv6']).each(function (version) {
        ipSelect = $(prefix + 'domainInfo-ipSelector-' + version);
        if (!ipSelect) {
            return;
        }

        $A(ipSelect.options).each(function (option) {
            if ('none' == option.value) {
                return;
            }

            if (isVpsMode) {
                var ip = option.text.split(' ').first();
                if (publicIps.indexOf(ip) == -1) {
                    option.remove();
                }
            }
        });

        splitPleskIpSelector(ipSelect, version);

        if (0 == ipSelect.options.length) {
            ipSelect.options[0] = new Option('None', 'none');
        }
        ipSelect.value = 'none';
        ipSelectRows.push(ipSelect.up('.form-row'));
    });
    var serviceNodeSelector = Jsw.getComponent(prefix + 'serviceNodeSelector');
    if (serviceNodeSelector) {
        webspaceObserve(serviceNodeSelector, ipSelectRows);
        createSubscriptionObserve(serviceNodeSelector, ipSelectRows);
    }
    hideIpSelectors(ipSelectRows);
};

function splitPleskIpSelector(ipSelect, version) {
    var form = ipSelect.up('form');
    $A(ipSelect.options).each(function (option) {
        if ('none' == option.value) {
            return;
        }
        var ip = option.text.split(' ').first();
        var ipHidden = new Element('input', {
            type: 'hidden',
            name: 'serviceNodeSelectorIps' + '[' + version + '][' + ip + ']',
            value: option.value
        });
        form.insert(ipHidden);
        option.remove();
    });
}

function webspaceObserve(serviceNodeSelector, ipSelectRows) {
    var webspace = Jsw.getComponent('domainName-webspace');
    var assignToCustomer = $('domainName-assignToCustomer');
    if (!webspace || !assignToCustomer) {
        return;
    }
    $A([webspace._dropdownList, assignToCustomer]).each(function (element) {
        element.observe('click', function (event) {
            hideIpSelectors(ipSelectRows);
            if (assignToCustomer.checked) {
                serviceNodeSelector.show();
                return;
            }
            if ('new' == webspace.getValue()) {
                serviceNodeSelector.show();
                return;
            }
            serviceNodeSelector.hide()
        });
    });
}

function createSubscriptionObserve(serviceNodeSelector, ipSelectRows) {
    var createSubscription = $('subscription-domainInfo-createSubscription');
    if (!createSubscription) {
        return
    }
    createSubscription.observe('click', function (event) {
        hideIpSelectors(ipSelectRows);
        if (!createSubscription.checked) {
            serviceNodeSelector.hide();
        } else {
            serviceNodeSelector.show();
        }
    });
}

function hideIpSelectors(ipSelectRows) {
    ipSelectRows.each(function (ipSelect) {
        ipSelect.hide();
    });
}

PleskExt.PleskMultiServer.reloadIpTypes = function (nodeSelector, nodeList) {
    var node = nodeList[nodeSelector.value];
    var ipTypesByVersion = node['allowedIps'];
    $A(['ipv4', 'ipv6']).each(function (version) {
        var ipTypeSelectorElement = $('subscription-serviceNodeSelector-' + version);
        if (!ipTypeSelectorElement) {
            ipTypeSelectorElement = $('serviceNodeSelector-' + version);
            if (!ipTypeSelectorElement) {
                return;
            }
        }
        $A(ipTypeSelectorElement.options).each(function (option) {
            option.remove();
        });
        var ipTypes = ipTypesByVersion[version];
        for (var ipType in ipTypes) {
            if (!ipTypes.hasOwnProperty(ipType)) {
                continue;
            }
            ipTypeSelectorElement.add(new Option(ipTypes[ipType], ipType));
        }
    });
};

})(); // END Anonymous namespace
