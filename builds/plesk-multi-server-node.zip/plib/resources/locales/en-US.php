<?php
// Copyright 1999-2017. Parallels IP Holdings GmbH. All Rights Reserved.

$messages = [
    'permissionDenied' => 'Permission denied.',
    'allSubscriptions' => 'All subscriptions',
    'invalidLicense' => 'The Plesk license is not compatible with the Plesk Multi Server service node.&nbsp; Please %%updateLicenseLink%%',
    'updateLicenseLinkText' => 'update the license',
    'invalidOrExpiredLicense' => 'The Plesk License is not compatible with the Plesk Multi Server service node.',
    'invalidOrExpiredLicense.customer' => 'The Plesk License is not compatible with the Plesk Multi Server service node. Please contact you hosting provider.',
    'backToAdministratorTitle' => 'Back To Administrator',
    'controllers.extension.list.pageTitle' => 'Extensions Management',
    'components.list.extensions.hint' => 'List extensions installed in Plesk and access the functions provided by these extensions.',
    'components.list.extensions.nameColumn.title' => 'Name',
    'components.list.extensions.versionColumn.title' => 'Version',
    'components.list.extensions.releaseColumn.title' => 'Release',
    'components.list.extensions.descriptionColumn.title' => 'Description',
    'components.list.extensions.helpColumn.hint' => 'See the reference for this extension.',
    'components.list.extensions.keyNo' => 'This extension requires a license key.',
    'components.list.extensions.keyAvailable' => 'The license key is installed for this extension.',
    'components.list.extensions.disabled' => 'This extension is disabled due to incompatibility with this Plesk installation.',
    'components.adminToolbar.dropDownItem.home' => 'Home',
    'components.adminToolbar.dropDownItem.customers' => 'Customers',
    'components.adminToolbar.dropDownItem.domains' => 'Domains',
    'components.adminToolbar.dropDownItem.subscriptions' => 'Subscriptions',
    'components.adminToolbar.dropDownItem.servicePlans' => 'Service Plans',
    'components.adminToolbar.dropDownItem.nodes' => 'Nodes',
    'components.adminToolbar.dropDownItem.tasks' => 'Tasks',
    'components.adminToolbar.dropDownItem.toolsAndSettings' => 'Tools & Settings',
    'components.adminToolbar.managementNode.title' => 'Management node: %%managementNodeLink%%',
    'components.adminToolbar.serviceNode.title' => 'Service node: %%serviceNodeLink%%',
    'components.adminToolbar.goto.title' => 'Go to',
    'components.accountToolbar.changePasswordItem.title' => 'Change Password',
    'components.accountToolbar.changePasswordItem.description' => 'Change the password for your account.',
    'components.accountMenu.changePasswordItem.title' => 'Change Password',

    'component.global.mailServer.settings.info' =>
        'Most mail service settings are configured on the <a href="%%link%%">management node</a>.',

    'component.api.cli.forwarded.utility.disabled' => 'Utilities: subscription, customer may be used on management node only.',
    'component.api.cli.forwarded.utility.domain.command.disabled.error' =>
        'Operations with subscriptions via domain command is denied on service node. ' .
        'You may used subscription command on management node.',
    'component.api.cli.forwarded.utility.domain.command.disabled.internalError' => 'Internal server error.',
];
