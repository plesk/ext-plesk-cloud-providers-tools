Jsw.namespace('PleskExt.PleskMultiServerNode');

PleskExt.PleskMultiServerNode.showAdminToolbar = function () {
    var adminToolbarWrapper = $$('.plesk-ext-plesk-multi-server-node--admin-toolbar-wrapper').first();
    var adminToolbar = $$('.plesk-ext-plesk-multi-server-node--admin-toolbar').first();

    function adminToolbarHeight() {
        adminToolbarWrapper.setStyle({ height: adminToolbar.getHeight() + 'px' });
    }

    $$('.plesk-ext-plesk-multi-server-node--admin-toolbar .dropdown-toggle').invoke('observe', 'click', function () {
        this.up('.btn-group').toggleClassName('open');
    });

    adminToolbarHeight();
    Event.observe(window, 'resize', adminToolbarHeight);

    $$('.plesk-ext-plesk-multi-server-node--admin-toolbar').each(function(element) {
        $w('webkitTransitionEnd transitionend msTransitionEnd oTransitionEnd').each(function(ev) {
            element.observe(ev, adminToolbarHeight);
        });
    });
};
