Jsw.namespace('PleskExt.PleskMultiServerNode');

PleskExt.PleskMultiServerNode.removeElement = function (element, upTo) {
    if (element && upTo) {
        element = element.up(upTo);
    }
    if (element) {
        element.remove();
    }
};

PleskExt.PleskMultiServerNode.removeElementBySelector = function (selector, upTo) {
    var element = $$(selector).first();
    if (!element) {
        return;
    }
    var toolbar = element.up('.objects-toolbar');
    PleskExt.PleskMultiServerNode.removeElement(element, upTo);
    if (toolbar) {
        PleskExt.PleskMultiServerNode.cleanToolbarSeparators(toolbar);
    }
};

PleskExt.PleskMultiServerNode.cleanToolbarSeparators = function (toolbar) {
    // remove separator if first
    var first = toolbar.firstDescendant();
    if (first && first.hasClassName('separator')) {
        PleskExt.PleskMultiServerNode.removeElement(first);
    }
    // remove double separator
    toolbar.select('.separator').each(function(separator) {
        if (separator.next().hasClassName('separator')) {
            PleskExt.PleskMultiServerNode.removeElement(separator);
        }
    });
};

PleskExt.PleskMultiServerNode.removeElements = function (items) {
    items.forEach(function (item) {
        PleskExt.PleskMultiServerNode.removeElementBySelector(item.selector, item.upTo)
    });
};

PleskExt.PleskMultiServerNode.hideElement = function (element, upTo) {
    if (element && upTo) {
        element = element.up(upTo);
    }
    if (element) {
        element.hide();
    }
};

PleskExt.PleskMultiServerNode.hideElementBySelector = function (selector, upTo) {
    var element = $$(selector).first();
    if (!element) {
        return;
    }
    PleskExt.PleskMultiServerNode.hideElement(element, upTo);
};

PleskExt.PleskMultiServerNode.hideElements = function (items) {
    items.forEach(function (item) {
        PleskExt.PleskMultiServerNode.hideElementBySelector(item.selector, item.upTo)
    });
};

PleskExt.PleskMultiServerNode.addElementByClass = function (targetElementClass, content) {
    var targetElement = $$(targetElementClass).first();
    if (targetElement) {
        targetElement.insert({top: content});
    }
};

PleskExt.PleskMultiServerNode.replaceLinkToText = function (selector) {
    $$(selector).forEach(function (element) {
        element.up().insert({top: element.innerHTML});
        PleskExt.PleskMultiServerNode.removeElement(element);
    });
};

PleskExt.PleskMultiServerNode.replaceLinkHref = function (selector, href) {
    $$(selector).forEach(function (element) {
        element.href = href;
    });
};

/**
 * Select DOM element by given selector.
 *
 * @param selector string|{'selector': "css-selector", 'upTo': "parent-element-selector"}
 * @returns Element|undefined
 */
function selectElement(selector) {
    if (typeof selector === 'string') {
        selector = {'selector': selector};
    }
    var element = $$(selector['selector']).first();
    if (!element) {
        return;
    }

    var upTo = selector['upTo'];
    if (upTo) {
        element = element.up(upTo)
    }

    return element;
}

PleskExt.PleskMultiServerNode.addStatusMessage = function (status, message, renderToSelector) {
    if (!renderToSelector) {
        renderToSelector = {selector: '.heading', 'upTo': 0};
    }

    var renderToElement = selectElement(renderToSelector);

    Jsw.addStatusMessage(status, message, {renderTo: renderToElement});
};
